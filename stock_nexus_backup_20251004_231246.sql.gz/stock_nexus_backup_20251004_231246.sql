--
-- PostgreSQL database dump
--

\restrict jvWi6xLhVJmsh8R116HanHAIemah1K7FLxJbbGCmoZD5L6zT22EUmf3os7mF3xe

-- Dumped from database version 16.10 (Homebrew)
-- Dumped by pg_dump version 16.10 (Homebrew)

-- Started on 2025-10-04 23:12:50 CEST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS stock_nexus;
--
-- TOC entry 3898 (class 1262 OID 16388)
-- Name: stock_nexus; Type: DATABASE; Schema: -; Owner: khalifainternationalaward
--

CREATE DATABASE stock_nexus WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE stock_nexus OWNER TO khalifainternationalaward;

\unrestrict jvWi6xLhVJmsh8R116HanHAIemah1K7FLxJbbGCmoZD5L6zT22EUmf3os7mF3xe
\connect stock_nexus
\restrict jvWi6xLhVJmsh8R116HanHAIemah1K7FLxJbbGCmoZD5L6zT22EUmf3os7mF3xe

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 16389)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3899 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 239 (class 1255 OID 16606)
-- Name: log_user_activity(uuid, character varying, jsonb, inet, text); Type: FUNCTION; Schema: public; Owner: khalifainternationalaward
--

CREATE FUNCTION public.log_user_activity(p_user_id uuid, p_action character varying, p_details jsonb DEFAULT '{}'::jsonb, p_ip_address inet DEFAULT NULL::inet, p_user_agent text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO activity_logs (user_id, action, details, ip_address, user_agent)
    VALUES (p_user_id, p_action, p_details, p_ip_address, p_user_agent);
END;
$$;


ALTER FUNCTION public.log_user_activity(p_user_id uuid, p_action character varying, p_details jsonb, p_ip_address inet, p_user_agent text) OWNER TO khalifainternationalaward;

--
-- TOC entry 251 (class 1255 OID 16607)
-- Name: update_stock_quantity(uuid, character varying, integer, text, uuid); Type: FUNCTION; Schema: public; Owner: khalifainternationalaward
--

CREATE FUNCTION public.update_stock_quantity(p_item_id uuid, p_movement_type character varying, p_quantity integer, p_reason text DEFAULT NULL::text, p_user_id uuid DEFAULT NULL::uuid) RETURNS TABLE(new_quantity integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_qty INTEGER;
    new_qty INTEGER;
BEGIN
    -- Get current quantity
    SELECT current_quantity INTO current_qty FROM stock WHERE item_id = p_item_id;
    
    IF current_qty IS NULL THEN
        current_qty := 0;
    END IF;
    
    -- Calculate new quantity
    IF p_movement_type = 'in' THEN
        new_qty := current_qty + p_quantity;
    ELSIF p_movement_type = 'out' THEN
        new_qty := current_qty - p_quantity;
        IF new_qty < 0 THEN
            RAISE EXCEPTION 'Insufficient stock. Current: %, Requested: %', current_qty, p_quantity;
        END IF;
    END IF;
    
    -- Update stock
    INSERT INTO stock (item_id, current_quantity, updated_by)
    VALUES (p_item_id, new_qty, p_user_id)
    ON CONFLICT (item_id) 
    DO UPDATE SET 
        current_quantity = new_qty,
        updated_by = p_user_id,
        last_updated = NOW(),
        updated_at = NOW();
    
    -- Log movement
    INSERT INTO stock_movements (item_id, movement_type, quantity, reason, created_by)
    VALUES (p_item_id, p_movement_type, p_quantity, p_reason, p_user_id);
    
    -- Log activity
    PERFORM log_user_activity(
        p_user_id,
        'stock_' || p_movement_type,
        json_build_object(
            'item_id', p_item_id,
            'quantity', p_quantity,
            'old_quantity', current_qty,
            'new_quantity', new_qty,
            'reason', p_reason
        )
    );
    
    RETURN QUERY SELECT new_qty;
END;
$$;


ALTER FUNCTION public.update_stock_quantity(p_item_id uuid, p_movement_type character varying, p_quantity integer, p_reason text, p_user_id uuid) OWNER TO khalifainternationalaward;

--
-- TOC entry 238 (class 1255 OID 16598)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: khalifainternationalaward
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO khalifainternationalaward;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 225 (class 1259 OID 16563)
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.activity_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    branch_id uuid,
    action character varying(100) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    entity_type character varying(50),
    entity_id uuid,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.activity_logs OWNER TO khalifainternationalaward;

--
-- TOC entry 218 (class 1259 OID 16427)
-- Name: branches; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.branches (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    district_id uuid,
    address text,
    phone character varying(20),
    email character varying(100),
    manager_name character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.branches OWNER TO khalifainternationalaward;

--
-- TOC entry 227 (class 1259 OID 16657)
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.calendar_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    event_date date NOT NULL,
    event_type character varying(50) DEFAULT 'general'::character varying,
    branch_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.calendar_events OWNER TO khalifainternationalaward;

--
-- TOC entry 217 (class 1259 OID 16412)
-- Name: districts; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.districts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    region_id uuid,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.districts OWNER TO khalifainternationalaward;

--
-- TOC entry 220 (class 1259 OID 16467)
-- Name: items; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    description text,
    image_url text,
    storage_temperature numeric(5,2),
    threshold_level integer DEFAULT 10 NOT NULL,
    branch_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    low_level integer DEFAULT 5,
    critical_level integer DEFAULT 2,
    CONSTRAINT items_category_check CHECK (((category)::text = ANY ((ARRAY['fish_frozen'::character varying, 'vegetables'::character varying, 'other_frozen_food'::character varying, 'meat_frozen'::character varying, 'kitchen_supplies'::character varying, 'grains'::character varying, 'fruits'::character varying, 'flour'::character varying, 'cleaning_supplies'::character varying, 'canned_prepared_food'::character varying, 'beer_non_alc'::character varying, 'sy_product_recipes'::character varying, 'packaging'::character varying, 'sauce'::character varying, 'softdrinks'::character varying, 'spices'::character varying, 'other'::character varying])::text[])))
);


ALTER TABLE public.items OWNER TO khalifainternationalaward;

--
-- TOC entry 223 (class 1259 OID 16529)
-- Name: moveout_lists; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.moveout_lists (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_by uuid,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    title character varying(255) DEFAULT 'Moveout List'::character varying,
    description text,
    generated_by uuid,
    branch_id uuid,
    CONSTRAINT moveout_lists_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'active'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.moveout_lists OWNER TO khalifainternationalaward;

--
-- TOC entry 224 (class 1259 OID 16547)
-- Name: notifications; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    type character varying(50) NOT NULL,
    data jsonb DEFAULT '{}'::jsonb,
    is_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO khalifainternationalaward;

--
-- TOC entry 216 (class 1259 OID 16400)
-- Name: regions; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.regions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.regions OWNER TO khalifainternationalaward;

--
-- TOC entry 221 (class 1259 OID 16489)
-- Name: stock; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.stock (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid,
    current_quantity integer DEFAULT 0 NOT NULL,
    last_updated timestamp with time zone DEFAULT now(),
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.stock OWNER TO khalifainternationalaward;

--
-- TOC entry 222 (class 1259 OID 16509)
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.stock_movements (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid,
    movement_type character varying(10) NOT NULL,
    quantity integer NOT NULL,
    reason text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT stock_movements_movement_type_check CHECK (((movement_type)::text = ANY ((ARRAY['in'::character varying, 'out'::character varying])::text[])))
);


ALTER TABLE public.stock_movements OWNER TO khalifainternationalaward;

--
-- TOC entry 226 (class 1259 OID 16608)
-- Name: stock_receipts; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.stock_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    supplier_name character varying(255) NOT NULL,
    receipt_file_path character varying(500) NOT NULL,
    receipt_file_name character varying(255) NOT NULL,
    remarks text,
    status character varying(50) DEFAULT 'pending'::character varying,
    submitted_by uuid,
    reviewed_by uuid,
    branch_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    reviewed_at timestamp with time zone,
    CONSTRAINT stock_receipts_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.stock_receipts OWNER TO khalifainternationalaward;

--
-- TOC entry 3900 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE stock_receipts; Type: COMMENT; Schema: public; Owner: khalifainternationalaward
--

COMMENT ON TABLE public.stock_receipts IS 'Stores stock receipt submissions from staff for manager review';


--
-- TOC entry 219 (class 1259 OID 16442)
-- Name: users; Type: TABLE; Schema: public; Owner: khalifainternationalaward
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(100) NOT NULL,
    phone character varying(20),
    photo_url text,
    "position" character varying(100),
    role character varying(50) NOT NULL,
    branch_id uuid,
    branch_context uuid,
    last_access timestamp with time zone,
    access_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    region_id uuid,
    district_id uuid,
    notification_settings jsonb DEFAULT '{}'::jsonb,
    stock_alert_frequency character varying(50),
    stock_alert_schedule_day character varying(20),
    stock_alert_schedule_date integer,
    stock_alert_schedule_time time without time zone,
    stock_alert_frequencies jsonb DEFAULT '[]'::jsonb,
    event_reminder_frequencies jsonb DEFAULT '[]'::jsonb,
    daily_schedule_time time without time zone,
    weekly_schedule_day character varying(20),
    weekly_schedule_time time without time zone,
    monthly_schedule_date integer,
    monthly_schedule_time time without time zone,
    event_daily_schedule_time time without time zone,
    event_weekly_schedule_day character varying(20),
    event_weekly_schedule_time time without time zone,
    event_monthly_schedule_date integer,
    event_monthly_schedule_time time without time zone,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'manager'::character varying, 'assistant_manager'::character varying, 'staff'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO khalifainternationalaward;

--
-- TOC entry 3890 (class 0 OID 16563)
-- Dependencies: 225
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.activity_logs (id, user_id, branch_id, action, details, entity_type, entity_id, ip_address, user_agent, created_at) FROM stdin;
026557bb-41a6-4631-82b7-2034d933c96e	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_login	{"email": "admin@stocknexus.com"}	\N	\N	::1	curl/8.7.1	2025-10-03 23:31:13.426696+02
fc1055ce-eb89-48cb-bafc-9be3d918f569	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_login	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:31:36.989435+02
9c998196-0cff-4567-bb99-b129d96b9bc7	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_login	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:31:45.315402+02
e25f815c-3e79-4ffc-8351-f33891bb5d3e	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_login	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:32:46.057711+02
af32f709-cfd8-4231-b886-4b4945614e73	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_login	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:33:11.09321+02
761df67a-04bf-41ca-8e6b-b9d9b1b26412	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_login	{"email": "aa@aa.com"}	\N	\N	::1	curl/8.7.1	2025-10-03 23:35:09.510123+02
f89e2de1-7a4a-434d-819b-1b447b3af78d	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	curl/8.7.1	2025-10-03 23:35:11.67893+02
c84987ea-32c5-4da5-a6a8-81899c438bb3	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_login	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	curl/8.7.1	2025-10-03 23:35:13.926169+02
89b8aea9-f176-4ca3-9238-28c6414efc95	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_logout	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:35:33.722918+02
13d8118f-298c-4c70-94d4-af491d78eaf2	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:36:13.0097+02
431f1e2e-27b8-4b51-be75-84b244e43374	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_logout	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:39:20.91655+02
780d9ce3-0ccb-4b1f-8b97-af99933bd5f8	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_login	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:39:39.146833+02
81497d78-bbb3-406a-b413-849fc04f754c	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_logout	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:41:54.39564+02
a1a656bf-d691-4ed1-90c7-237ce69287be	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_login	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:43:43.156057+02
51a727a3-ada6-48cc-bf01-62fefab342f5	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_logout	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:45:50.940462+02
e089f822-72cf-4454-b1d5-6f22f9d957e0	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_login	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:46:19.496702+02
d32c2704-cc9e-42f1-8c25-472bcad1b20f	7c6fc959-5e6e-4b57-ad76-66abb86a16ab	\N	user_logout	{"email": "admin@stocknexus.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:52:42.004566+02
fd6aff11-1f33-4039-b590-d351c96ea1e6	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_login	{"email": "aa@aa.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:52:46.084858+02
06f16e08-ab3a-49a1-bf45-d2e7f387fdc7	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_login	{"email": "aa@aa.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 23:55:25.850631+02
f7fad99c-75a7-4cc3-b0ba-2f2618a4c4e5	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	item_created	{"name": "Surami", "item_id": "9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0"}	\N	\N	\N	\N	2025-10-04 00:01:17.944293+02
f09076a6-2dfa-4d14-b441-11dd55fbe8c1	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	item_updated	{"name": "Surami", "item_id": "9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0"}	\N	\N	\N	\N	2025-10-04 00:01:56.334841+02
e40b70a1-9296-4bdc-81a4-bdd11c7d3ca5	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	stock_movement	{"reason": "Quick stock in", "item_id": "9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0", "quantity": 10, "new_quantity": 10, "movement_type": "in", "previous_quantity": 0}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:02:06.479204+02
8022decd-44e0-4aa8-84a0-fffb1bc91281	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_logout	{"email": "aa@aa.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:02:10.938921+02
6c564658-fd0a-4706-a219-ad40716443da	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_login	{"email": "aa@aa.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:02:12.815988+02
636ef414-e0cf-4d23-9650-972654c9315e	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	stock_movement	{"reason": "Quick stock out", "item_id": "9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0", "quantity": 1, "new_quantity": 9, "movement_type": "out", "previous_quantity": 10}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:02:58.900255+02
42c900ee-6ecf-41ca-ae3e-93455d3ed89b	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	staff_deleted	{"staff_id": "3edce773-cadd-43f2-ad49-5dc72a2c80a4"}	\N	\N	\N	\N	2025-10-04 00:03:16.976469+02
bdacf14e-af14-4c28-82f6-a8644423684c	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	staff_created	{"name": "Kaumadi Mihirika", "role": "staff", "staff_id": "3edce773-cadd-43f2-ad49-5dc72a2c80a4"}	\N	\N	\N	\N	2025-10-04 00:03:38.66061+02
d63d6896-b4fd-473b-9546-fd7156cd2659	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_logout	{"email": "aa@aa.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:03:57.83884+02
8d92aaa2-477c-4e3f-aca1-12223bed799e	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_login	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:03:59.900448+02
634d6ee7-a12e-46b2-9714-2bc54f162c30	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_login	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:24:06.674531+02
c3825185-db00-4c02-8681-aa781a7d639e	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0.1 Safari/605.1.15	2025-10-04 00:28:03.631455+02
92e2718b-eee1-477b-a6fa-e38bb595b430	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0.1 Safari/605.1.15	2025-10-04 00:29:08.488083+02
763a1526-eefb-4e56-98c4-ed19eee80127	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_logout	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:39:05.450328+02
e77bfd76-b6dc-4ee0-8d29-debfc2da50e1	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:39:09.586098+02
c2dd27b6-3929-4166-ae31-4ef7658023c1	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_logout	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:41:49.327497+02
71c58a9d-747a-4c8b-8627-bd841ae4f84f	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_login	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:41:52.927622+02
b4d5b3cf-ba72-4974-83d0-9bb6ae5ce361	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_logout	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:42:18.280043+02
ed252c9f-c7c3-4813-ba3c-2826c9168213	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_login	{"email": "aa@aa.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:42:21.770412+02
9b5eb554-f98c-4a37-90d2-9ae9bebf222e	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	stock_movement	{"reason": "Quick stock in", "item_id": "9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0", "quantity": 10, "new_quantity": 10, "movement_type": "in", "previous_quantity": 0}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:42:28.291618+02
13576bc0-0ea2-4f90-ad63-513b29c1cfb1	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_logout	{"email": "aa@aa.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:42:30.663989+02
89d5a238-0299-463b-bb61-0cd0f4c39b11	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:42:35.338121+02
12d7c52a-5382-48be-8726-17fdf439f349	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_logout	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:42:54.682061+02
eb47841c-9a95-4d56-99a7-ccd1a36e475e	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_login	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:42:58.074748+02
a5bc5f96-651a-41a8-b198-9c81d2c02232	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_logout	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:43:13.584545+02
8c9ae2c3-14d7-49e6-8fe7-f9eaef5e7879	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_login	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:43:49.794393+02
de0ade48-1535-420f-a53f-af4d1dde08b3	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	curl/8.7.1	2025-10-04 00:50:16.738919+02
59831c67-17fa-41cf-a231-91c07d30c2f3	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	curl/8.7.1	2025-10-04 00:50:19.377842+02
1a397af6-a57d-40b5-9275-081d4deb2e64	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	curl/8.7.1	2025-10-04 00:50:40.837808+02
9672a66d-f337-4935-905a-59d53ed8b9d7	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_login	{"email": "slaksh7@gmail.com"}	\N	\N	::1	curl/8.7.1	2025-10-04 00:50:43.578209+02
634dd4f1-4d91-49e8-a4ea-94442e2f5caa	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_logout	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:54:08.692937+02
cf461b9c-417c-41fb-b653-f0a38b072335	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	\N	user_login	{"email": "aa@aa.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 00:54:12.958622+02
141d6770-5c14-4c70-a958-5a1e64046415	572c001e-2c97-40c1-8276-c73a0bb6572f	\N	user_logout	{"email": "slaksh7@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0.1 Safari/605.1.15	2025-10-04 00:54:30.42388+02
c10ff1e6-4655-45f5-ba08-5db732e9c384	3edce773-cadd-43f2-ad49-5dc72a2c80a4	\N	user_login	{"email": "kaumadi19910119@gmail.com"}	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0.1 Safari/605.1.15	2025-10-04 00:54:45.715258+02
\.


--
-- TOC entry 3883 (class 0 OID 16427)
-- Dependencies: 218
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.branches (id, name, district_id, address, phone, email, manager_name, created_at, updated_at) FROM stdin;
e3204bd8-ac3d-413f-bd7b-2727e9c7f598	Main Branch	5995e063-ae11-414b-add9-1e79d44e107b	123 Main Street	+1234567890	main@company.com	Jaber Ahmed	2025-10-03 23:55:37.13693+02	2025-10-03 23:55:37.13693+02
bb6313ee-0513-4805-81c2-3072e9618640	Secondary Branch	5995e063-ae11-414b-add9-1e79d44e107b	456 Secondary Ave	+1234567891	secondary@company.com	S Laksh	2025-10-03 23:55:37.139845+02	2025-10-03 23:55:37.139845+02
\.


--
-- TOC entry 3892 (class 0 OID 16657)
-- Dependencies: 227
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.calendar_events (id, title, description, event_date, event_type, branch_id, created_by, created_at, updated_at) FROM stdin;
a7077716-c0ec-426c-b892-109aa910c84a	cbcb	\N	2025-10-10	delivery	e3204bd8-ac3d-413f-bd7b-2727e9c7f598	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	2025-10-04 01:25:47.876148+02	2025-10-04 01:25:47.876148+02
\.


--
-- TOC entry 3882 (class 0 OID 16412)
-- Dependencies: 217
-- Data for Name: districts; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.districts (id, name, region_id, description, created_at, updated_at) FROM stdin;
5995e063-ae11-414b-add9-1e79d44e107b	Main District	c33dc2c6-297e-482e-8987-de0f188642bd	Primary district	2025-10-03 23:55:37.132965+02	2025-10-03 23:55:37.132965+02
\.


--
-- TOC entry 3885 (class 0 OID 16467)
-- Dependencies: 220
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.items (id, name, category, description, image_url, storage_temperature, threshold_level, branch_id, created_by, created_at, updated_at, low_level, critical_level) FROM stdin;
9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0	Surami	fish_frozen	dafafafa	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAACAASURBVHic7N13fBzltTfw3zOzRbuStqi3VW+2XLEx3XRTbAMJLb0Rk0ASLiGF5IYQbnpucu+FcJMQkhdSCcHhAjY2NWCKaS64W5ZWVrVktd3VrrR95nn/kE0MbprZMrPr8/18EgzamTm2pX3OPuUcgBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCjotpHQAhyXJFY2WVAeLZMnghA/cLorx5zb7BfVrHRQghekQJAMl4VzXWLJS5/J9guBhHfU/zdwUm3Lmms+8FTYIjhBCdErUOgJBErGyq+hgH1oKhGcdMaFk5Bz7RVGiXOz3+V9MeICGE6BQlACRjrWyouYgDjwMwneSljAEXNjkdQ53eiS3piI0QQvSOlgBIRrrgAhjyBlw7AMya+VUsIEhi05ru7uGUBZYAzjnrCKCQA4WGWLyQM1bIGYoExgo55ELIYGAsl/PphIcBDjAwDhgYkAfAd+hWUc4xBQCM8SlwRBlDVIYwzjgfY5yPMwMfj8rGUTmGsbYSNqnV75kQoh2D1gEQokbeQPUVAFcw+AMAz5cNsU8B+HlKgjqJ7Qd5bq4pWidDrBUYq+OQaxlYLQerA3iV2ycVCYeSci5M5+YMAOd8+leH0nX2gbT9WFn8v14zfd30Hfj0rxkDlxkMkAAj0OmNRwCMcaCbAT0MvJuD9TDGe2QYevx29C9mLJb0PxBCiKYoASCZicsXHzUSzug6dglSnAAMDnJryBqbLUOYzzify8HmApgLSMUc4vSg/q8hGTj0/xoyA6hkQCWAc/mhlIJzBgYJdh+kTm+8F8AOBr6TM7ZDEMQd9fnoYoxJWgZOCFGPEgCSkRiYS92wyauTGcfgILdOWeJLGBfO4YwvAPi8KUgN4IIIADw7VtlEAPUA6jnYNeCALElw+xDs9Mb3ANgOzrYIiL9e7zTtZozJGsdLCJkBSgBIRpKBiLqhVQgn8tzuEV4WN0inA/wcMHbuFKTFADNzdjgdyYoBf6asABYDWAzGb5Ihwu2TJju98e3g/HWAbTQw8bU6J/Od7EaEkPSjBIBkJMZYh5qpcw7eoeT1XR5ulwTpEsZxBQMujkOqPRSB4mefIvIAnAPGzgGAOKR4hzf+LmP8BUHGM31Ow1sXMhbXOEZCCOhdjGSoqxprFsqQtyq9jjH+8bWdA4+c6DUdPl4PLq8UwFdwYClOfsyQzNwUgJcZY2shCc80FrJ+rQMi5FRFCQDJWCsbqp7mjC2f8QWc7Zt09c3ZsAHv+wT6MueGqon4ReDsegYs50B50oMlx8IBtgOQn4IsP9ZUaN6tdUDZ7sr6ymZRFC8El0tlCH6RY5O5q++t1YCqzZwrKyqs3Gq4GExu5WA5AniXQY69+ETX8EiyYyfJRwkAyViXzaopN8bkdwBUzeDlYSZj6dr9/ZsAgHMu7PfGz+YM13OwGwGUpjRYMgN8D4DVsmR4tKWItWsdTTa5sr6yWRCE+wEsO8aXOzgT7ljX2btOwS3ZygbX1zjDvwNwvu8LQIxz/D/BEPrmmn1jgUTiJqlFCQDJaCvqq5ogYA3AWk/wsmEms+vWdPVu7PTFz2OM3QiOa0GDvo6xbeB4TBKER1sdrFvraDLZysbKMzmE9fjAQP0BMhj/1tOdAyc9Int9W5spFAk8AvBrT/LSXRJiFz3jPjiqKGCSNpQAkIx3RWOjWWTRL4LLnwbYwiO+5GYcf7vy83c8dOktty3jHF8B+BzNAiVqyADeZIz9yRwQ/uxysZDWAWWSDzWUlsSYaQdmmOwyjrvWdvX/6Hhfnx78/f8AsHJG9wN7ea2772LooNgFORolACSrrKyosCLfWFpYXuf99ydfWMw4uxnA1aCNfNnAyzlWi5D+t6HAvFPrYDLB8kbXfzPgq0quOV4SoHTwf+9+wDVr3f1PKbmGpAclACSruAO8RI7LNwvgN3GgVut4SMq8yjl+63eKq6lM8bHdAwibG12DULHUxRnuXtfZ/4PD/359W5spGPE/xqaTaUUYsHqtu/8GpdeR1KMEgGSFTh9vYDx+Gwf7PKYL1JBTAcNBcP5bEzPcV+NgXq3D0ZOV9RXVXBB71V5/OAlIZPA/ZP/T7v4GtXGQ1KEEgGS0Lk/sXJmx2wB8GNTe+lQ2ycAfEmD473onUz3oZZPlTTWzGJf3JHIPBvY9Dr4YCqf9P2D0aXd/SSJxkNSgBIBkHM650DUhXc85vo7pUrSEHBZnDKs5l3/e5DS9q3UwWlpeXe1kJj4Ozd/n2ban3X0LT/46km6C1gEQMlOcc9bpia90++StnONR0OBPjmbgHB8FhK1ub/yFTm/0lB141vX1eQEorpaZbAz8n1rHQI6NEgCSETp8sUvcPnkzGNYAfL7W8RD948AlgLCl0xtfu98Tmad1PFrg4Pdq+XwGxOLAb7SMgRwfJQBE1zp8sUs6vPF3GGcvAPw0reMhGYcBWCEx8d1Ob/yxrgnepHVA6XS6e+ARAGu1ej5n/DvPuPu7tHo+OTHaA0B0qcsXXSxx4X8YcK7WsZCsEgPD72VBvLvFxsa0DiYdrmopypelnGcBdnaaH/2rp939X07zM4kClAAQXdkzyssNonQPY7gJtKufpI4PjP0UduHeJsYiWgeTasvmleaagqZ1AM5Px/MY4w+u7Rz4IqgCoK5RAkB0YTfnJqNPvoWBfx+ATet4yKmCd4Cxu5ochtVaR5Jq6UoCaPDPHJQAEM11euIrwXAvgHqtYyGnJga8CC59tbHAvEvrWFIp1UkADf6ZhRIAopm9Xl5r4NIDYLhM61gIARAH5/9lmDDcU1fHwloHkyqpSgJo8M88lACQtJsu5CN/nnP+CwD5WsdDyAe4GeNfaHQYX9I6kFRZPrfayUK8A0BRMu7HgM1r3f1LQIN/RqFjgCSt3J7IHLdXeoNz/lvQ4E/0qZFz9mKnN/6n3RO8QOtgku36tjYTQvxhJGnwBwAOLF7e5LorWfcj6UEzACQtNnNutE/Id4Dz/wBg1joeQmaCAUMyw1eaHYbHtY4lGZLQ2OeEPthFkOgbJQAk5fZ5o/MFiH8FeJvWsRCi0l8FLn6poYBNaB2IWqke/A+jJCBz0BIASRnOOevwSv8mQHibBn+S4T4uM2lHhze2VOtA1EjX4A8AjOP7y5tc3031c0jiaAaApMT+SV4aj0sPMY4rtY6FkCSSwPkvok7D3W2MRbUOZiaub2szhSL+fyCxlr6KMY671nb1/yidzyTK0AwASTq3N/4hKSbtpsGfZCERjN1p9EmvZ0pfgVAk8CukefAHAM7wwxUNVavS/VwyczQDQJKmu5vnxO3SL8FAP/TkVDAJjluaCgx/0TqQ41nZ4LqGMzyhYQghCXLzM+4DAxrGQI6DZgBIUrjHuSvukF6hwZ+cQvLA8OcOT/y3uzk3aR3MscgMX9c4BIvAhC9qHAM5DkoASMI6vbELuCBtBrBE61gISTfGcLPJJ73UPsortI7lSFc0NtoYcKbWcYBTpU+9ogSAqMY5Z50+6U6AvQigROt4CNHQOaJB2ub2xS7SOpDDDEK8Agl21GSMPwjwNxK6B3h1IteT1KEEgKjSPsrz3T7pMXD+U1DbXkIAoJhz9tx0Uqw9KcZCiVx/uLZ/1BpbBuCVBO40lUgcJHUoASCK7fXyWtEQfwvAdVrHQojOGMD5Tzu98Yc2c27UMpDc7u4BAB6Vl//qcGOf53cMTwliaGUCMwE7VV5HUowSAKJI10T0dAOktwA2W+tYCNGxz9p90rPdXu7QKoDVgMQY/4eKS3/1tLv/Kziisc+afWMBQQxfriYJYAyPqoiBpAElAGTG3N74NbIsbABQqnUshGSAi+KIb9zv5TVaBSDI8g8ZoKR88VGD/2FqkgAObF7U2f93Bc8naUQJAJmRDq/0bxz4BwCr1rEQkjnYbIlJb3X5oou1ePpTXYP94PyjAMIney0D7j3e4H/Y4SSAAa/O4PH9XDJcdw8gzzxikk6UAJAT4pyLbm/sPgZ+L2izHyHKcZTJXNjQ6Y1fpcXj13YNPMNkLAX4u8d5yTBj+Oxad/9XcYLB/7A1+8YCOWbbpeDs5wAix3gJB8MTgmQ4fX13d28isZPUokqA5Lg2c260e6W/gOEGrWMhJAtIHPh8s9PwB42ez65scp0ncn4B56wcjPs4wyZhSn527eBgUM0Nr6ytLRMN8RUAa+OAAUA3E8T1azt62pMcO0kBSgDIMXVyboZPehTANVrHQkgW4QC7o8kp3qt1IITQEgA5yuAgt8InrQUN/oQkGwP4/3R6pbu1DoQQmgEg79Pl4XaZSesAnKN1LIRkNc5/1lRg/JbWYZBTFyUAaXBVS1E+YKqQ4oY8JsqiHEcIsmF0fU/PQa1jO1KvjzujsvQMGM7QOhZCTgkMv260i19hjNFOeZJ2lACkwMr6imqIhmtkzi9iwGIAlcd6HQMmOMNOJuNlMHn9WveBt9Ic6nv2+nmhQZJfBvhcrWIg5JQ0nQR8mTF20h34hCQTJQDJw1Y2VS/nXP4qwC6Auv0VnQAeiFqjv31+x3Da6md3jnMbF6QXGXB6up5JCPkXBn5fo9N4u9ZxkFMLJQBJsLyh5mzG5PsBnJakW46B4buLO/sfvCfFRTQGB7l1yiI9A2BpKp9DCDkZ9r0mp/h9raMgpw5KABJwQW1tTp5B+gWAW5GaP8u3mCh8bO2+3u4U3Bu7OTeZJqQnwXFFKu5PCFGGM3Zns0P8T63jIKcGSgBUWtFcVQkZawG2MMWP8smcf3R918CzybzpZs6Ndp/0OICVybwvISQhnHN2a3OB+IDWgZDsR3UAVFhRX9UEGRvTMPgDgENkbM2KxqqPJ+uGnHPB7pX+Ahr8CdEbxhj/VacnnrSfd0KOh2YAFFrRXFXJJfY6Y6hN86MlgH3kaXefmvae79Ppjf0PwGjDEUkqzjlCAT/i0TBikQjCU5OQYjGEpyYRj0YQDf+rH40sxRCeOnb1WaPZDKM5571/Fw0GmK25MOZYYDCaYMnLg2g0wmzNg9lihWg0pvz3poEYZ3x5s8P4gtaBkOxFCYAC11dVWUIW9hY45mkUQphBOGetu3er2ht0+KQvMM5pepGc1JTPg0nvOAKecfjHhhHwjCMwPoaAZwzhST+C/gmEAn6EAof+ORnQJE5TjhWWfBusNhss+Tbk5NlgtdmR6yiArbAI+YUlyHMWwF5ciryCQuQ5CiGIGdHXyi9y6bz6AvMOrQMh2YkSAAVWNFY/CPBVGofhFsTQaWv2jSl+t+3wxJczhqdAXf1OeVI8Du/QAMYG+uAbHoR3+CC8Q/3wDQ/BOzwE3/Ag4tGo1mGmhCCKyC8oRkFFJZylFbCXVsBRWobCChecZZUorq593wyExg5AFs9sKmQDWgdCsg8lADN0ZZNrqcCxATr4M2PAvYdad86Y2xddxLnwCoDcFIVFdMg3PIjh7i4M93ZhvL8Xo33dGB3ohWdwALIU1zo83XKUlKPIVYMiVy2KqmpQXF2LsvpmFFVVQxANaY6GbY3GhPPbSthkmh9Mspzmg1kmuB4Qg42uHQyYrXUsh8QZ2IK17r7dM3lx5zivgiC9heNUJCSZL+j3YaB9N4a69mG4240h9z4Md3dqNi2frQwmE0prG1FS24jyxmaU1zejonk2CspT+6PFGdYfsItXX8gYZW0kaSgBmIEVDa4bwfCo1nEciXP8bV1X/8dO9rr2UZ4vGuQ3Ad6WjrhI6gXGx9DfvhMH9u3CQPtuDLTvgmfogNZhndKsdieqWmbDNWsuKpvbUNXahuLquiQ/hd/b5DQqmvkj5EQoAZiBFU2ud8B1VyZXYrJUv3b/YN/xXsA5Z26f9HcA16cxLpJk4wf6sH/bZvTs2IyudzdjpMcNzqlsvN7l5Oahum0+6uafjvoFi1E3fzGMZnNC92TAZxqdhj8mKURyiqME4CSubqyeLYHPaKr9BHwA1nOGdsYxBaAOwOUAGhO5KQe+s87d/+Pjfb3TJ90Jzn+ayDNIeknxOAY729G9fRO6t29G5+a3MOXzaB0WSQJBNKCyuRW18xajfsHpaFp8JnIdBUpvEwKTz21ymFSfBCLkMEoATmJ5k+u7jENtfW4JHD+x5IR/tnr36Ac38LAVjdXXAvx/AZSqvP/Wp939i471BbcvdhHn7DkA6d6xRBSIhoNwb3kb7s1vonv7FvS374QUi2kdFkkDxhhKahtRN38RGhYuQcsZ5yG/sOjk1wE9MVFcPMvGxtMQJslilACcxIpG18sALlBxqcSAa9e6+5860YuubqhwSUx8BdOzAkrJMTMvfm73wPs+IrrHuYsL0hYAxSruSVJs/EAf9r29EbtfexGd72xELBrROiSiE6V1TZiz9GI0LzkXDQuXHL/IEcfzjU7xSsaYlN4ISTahBOAE7gGEzY2uAACr0msZx11ru/p/NJPXXtlUuUDgwiao+LQuc37FkX0COjk3c5/0GrX21Y9oOIieHe9i16svYverL9CGPTIjphwrGhefibbzLsGss5fCWfbBkwbsnian+B+aBEeyAiUAJ7CyvqKaC2Kv0usYx1BAEus39PSET/7qacsbXA8zhs8ofRYYu/3pzr77Dv+r2xf/Def4ouL7kKQadO/D3o0vYe8br6BnxxZIcTq9RRJT0diClrPOx6yzL0DDwiUQRFEG41c0OYzPax0byUy0PnxChmpA+W5rmeEJJYM/AIgCe0Tm/DNKn8U4dx3+tdsTv4JzfEHpPUhyHNzfiW0vrse2F57GcI9b63BIhuCY2SexQfc+DLr34eU/PwirzYHZ514ozD3/ssde3t4558L5TVQpkChGCcCJMDlfzSSJwJji2t2iHNkuM5PiZ4HxfABwB3gJj0sPg2Z10ooGfZIoNT+wQb8Pm9c/gc3rn7DnWPP2r2isehQQVg/Zi5/dsmUL7SIlM0IJwAnIjBlVjaYcx25zdgKGHDkYU7EXTJaZiXPOunzSQ1B/moAocKBjD7a/uB7bX3oGI737tQ5HvxiworoSDpMJZgODyKa7j5tEEUbhxD9ZsswRkg7tb+NAMC4hzmVEZRmRuASJcwSlOEJxGcF4HKGYhCkpjmA8jmBs+uuninBw0giwTwL8k+UTI2MrGqufEBhW+yv7Xt6wAbT2RI6LEoATELgwyZms+DoOVCm9Jhi1uhiUP4sxTHb65NsYsFzxxWTGfMOD2LTucWxa9wRG+7q1DidlRMZgMxlRmGNGgdkEh9kEq0HEmu4DkJUuh3HAJApYWpH+wyjBuAR/NIZALIaJaGz619EYvJEoPNHo9D/DUcRk5T9zOlcE8FUyx6q8Adf4ikY8yjl7eF1X3xatAyP6QwnACUhC3CNwQfF1DLgUwE+UXcOXKX4QgBJXjcDAFT2LzEw8GsXODc/jnadXY9/br4NnyWCRazCgxJKDYosZJZYclFjMKM7JQUGOCXaTEQI7+tN5l38SO8d9ip/15sExXO4qT0bYilgNIqwGEWU4cVc/fzQOTyQCTySCkVAEw8EwRkMRjITC8GV+N8RCAF9ijH9pRZNrB8AeYiz+17Udg2NaB0b0gdaLT2DZvNJcU9AUgPI/Jy7LWLJ+f//mmbz4+rY2Uyji3w0VlQFvvOsnfWde/ZFqpdeR4xto34131q7GlmefQtCvfNDTC7MoojLXgqo8C6pyrajKtaI814Jcg/K8f/OIBw/uVbfH4TuntaEmP/OaUEYlGcOhMPongxgMBtEfCGIgGEQgmtGz6lGAreWMPWzt7H12NUB1BE5hlACcxMpGl5sDDYovZNhhMYXPOUYFwKMsb3T9NwNUNfn4xiPPoKKpVc2l5AihgB/vvrAObz7xVwy0J1r5Of0cJiOq83NRYbWgPNeCmrxclFtzwI7xaV6NmCzj62++i1Bc+XixzFWO6+pdJ39hhgjG4hgMhtA7GcRQMIgDUyH0BYIZt5zAOIY4+GqZ4/fr9w/s1Doekn6UAJzE8kbX7xlwk5prObBRlAzXrunuHj7W168HxFBD9U/A+DfU3D/X7uQ/eH4zY4LyZQoybaB9N177+8PY+txaxGOZMeWbbzKg3paPJlseGmz5qMyzIEcUU/7cP3X04PWhEcXXOc0m/PTMBVn9ZhPnHAeDIez1TGD1/n6tw1GKg/GXOGe/PN3d//Q9ULEZiWQk2gNwEgzsWYCrSgAYcI4sxttXNFbdK0JYbXL37VsNSFfW1paJRunyIMc3GPhstbG1nnU+Df4qcFnGno0v49VHH0bHOxu1DuekinPMaLDnodFmQ6M9D+W5Fk0G0zNLC1UlAN5IFN3+AOpt+SmISh8MjL23zPLS4DDGw5mRTB7CwNnFDLh4c6OreznYb+Nm+XcfLDFOsk82J+VJcUFtbU6eQRoC4EjC7SQAUQCWJNwLN//yD5h11vnJuNUpYdI7jjeffBQbV/8FE6MHtQ7nmETGUGvLRaMtH032fNTbcpF3vHrwacYB3PX2doyGlZ9XvaSqDDc0nBpbVX63twubRjK+T88kA/4sM+H+dZ29e7UOhqQGJQAzsKKh6l4w9m9ax3Gkwspq/Pvj/4Qg0iTOyRzo2IM3Hv8LNq9/EtFwSOtwjmIzGTDbace8QifanHZYDKmfzlfrqe4BrOsbVHyd02zCT8+Yn7Q9CXr20oFhPOpWXEEcDGrqjqYeBzYC7D6ru+//aNNgdqHRYwYkxn8hgt0CQEWpvtS4+NNfpMH/JPZv24x//vE32PP6S1qH8j6HP+XPL3RilsOG6vzcjMnEF5UUqEoAvJEouvyTaLRn7zLAYfX5eaqua3bk4/yKUuwY92Ln+ASmdNI/ggHnAPycUKNr/wrGfilx0wPPuN3UwjILZMr7juZWNFT/p9rNeslWVt+Er/91PUQVx7myHecceze+jBce+hV6dm7VOpz3FJpNmFfkRFuBA632fJjEzN278b1NOzEUVD6TclFlKT7SWJOCiPQlzjlue30z4rKyz/N5RiP+++yFAACZc/QEprDLM4GdHh96A1OpCFUVztEjMPw8EBcfUtrzhOgLJQAzdH1bcV4oYt4FME3fwZgg4EsP/A0NC5doGYbuHN7Y99zv70P/Hn2caCrMMWF+oROLiwvQYM/Pmh+2tT0HsLZXeUtjh8mEn52V3acBDvvR1t2qBu2fnjEfBTnmo/67JxzBu+M+bB4dx/6JSZ0sFfARQPiNIS7c+2RPT+YWzDiFnQo/i0lzZVPVGQJnr0LDpYBLP/cVXHnLHVo9XnekeBxbn1uDFx/+NUZ6u7QOJ2sH/SMdDIZx9ybF/a4AAHctmoPqPGuSI9Kfv3T04FUVJyZuaWvCwiLnCV/jjUSxdcyrp2TAz8B/EzXjP+nkQGbR724jHer0+A+0FNg90Kju/qyzL8AN//4j0NE/QJYkbFr3OP5w5y145+l/YGrCq1ksxZYcnF9RjI801uLaehfmFDhQkGPOysEfAPKMBrw75oU/przpnN1kRIvDloKo9MUXiWGHR/mH4lJLDlqdJ/7zsRhE1NvycG5ZMc4tL0aB2YSwLMEX0ezooRlg54qScGuz02atdhZt3e/10h6BDEAJgEIdHv+mpgKHwIC0nr+rnXsaVt37exhMR08Pnko459jx0rP4w5234u01jyE0GdA0niUlhfjGglmY5bTDbtLHcb10mIzHsc/nV3xdSJJxfkVJCiLSFw7gtaFRxdeZRRFnlBbO+PVHJgNnlxXDahThCUcRVFGxMQnMYFhqYPKq5kIbn2+1vbvH79fHTkZyTJQAqNDpmdjQXOjwAViGNCyjNJ1+Fr/53oeY2ZJ59dSTqeOdjfjTd76MV//2sKaf+I80OBVCRa4VFblJKe2QMfKNBmwYVD7F7Y/GcFZZEaxZvoE1z2jEs/1DiqfnI5KEZSqbJ1kNIlocNlxUWYrZTjtEgeHgVESL1shWgF0aN2BVU4FDbCwo3uz2eOj4oA5RAqBSh2fi7RanfQcYLkOSCvscAz/jqo/0f/on9zuM5hN3Nctmvbu24ZF77sBzv/sl/KPKB51U2+2ZwGnFTt0U7EmHfKMR74yOYyqm/ANesSUHdTZ1R+UyhcDY9DJJVNkySUSScUFlCcwJlHZmjKEgx4x5hU5cWFWKcqsFkbiEcRUFnBLDchlwiYD4J5ucjuAC78S2PfosdXDKogQgAR1ef3uLI+9vYEIDgJYk377zvBs++bPrv/2j607VNf+R3v149AffxJpf/gSewQGtwzmuOOfY4wng7LIiGE6hvytPJIIu/0l7XR1FkjnOKitKQUT60hOYQv9kUPF1cwocKDrGSQA1jIIAV54VZ5UVYXFJAUyiiIPBcJobFzEHY1gZL7Bf3Vro6NrnmdifxoeTE6AEIEEd3sBEh8f/aKPT9jabTgQSbXs2yMHulmH+3Nf+8PgPAWT/wekPiIam8MLDv8Ff7r4dB/d3ah3OjEzF4xgLR7GouEDrUNLGKAh446Dy1vLeSBSXVJVlfbLkiUSxyzOh+Lqa/NyUzJDkG42Y7bTjkqoylFhzMBqOIKBwhiJBZRz4ZLPTfu6sQseWfZ4J5ZskSFJRApAknV6/u8Mz8f9aCvKfY2AxTCcCEl/1SwAAIABJREFUM/0pDgJ4loHdLcF863p398bn3COXcYZvpy5i/eGyjM3rn8Dv7/g89rz+EmQpfcuGlbkWSBwJfTIanAohz2jI+untw5xmE14ZHEVU4Z8ZB1Bvy0eZNbuXtSISx5vDyhOkArMZ8wqT0Xrk2ATG4Mqz4oKKEsxy2hCRZAyHwumbm2eoB3Bzs9NWVO0sepNODGgnW08q6cLKxuo2MH4657wFQCXA8hnnRs7YJDgfBmMdMsNOzs1vf7C0Zqc3/jaAU6baj3vLW3jiv76Pwc709R0RGMOcAjsurirDLIcN3YFJ/GJbe0JJgMgYvn1a2ylx1h0A/tC+H2+oGOQuqCjBx5pqkx+QjkzGYrjjjXcVX9dgz8OdC1Q3CVVlIhrDq4MjeOnAcLpLEI+DsR9YOvv+l/oMpB8lADrk9sav4cATWseRDt6hATx574+x46Vn0vZMiyji/MoSXFxZdtTRvS2jXjy4pzOhT0PFlhzcvagtoY1cmeLdMS9+s1v5Mk1xjhk/OmN+CiLSl6+9uRWBqLIB1WoQ8T/nLNLkzTkiS3jz4Die7x/CWFo3DbJtXOC3revofy2NDz3lZf87VIbhnDNPGI8CKNM6llSSpThee+yPePjOL2Gwc09anplnNOIyVzlWzWrAvEInco4xQFfkWhDnMtwTyje3HRaMxzEZkzA/hdO4euE0m/B8/0HFCVMwLuGM0kLkGrP7OOBurw9jYWUFemIyx3nlxZp0hTQwAbX5ubioshQVuVYMToUwqeKkhwpljOMzzQW2hoYC6+tuj4rdk0QxSgB05pO3f/dDAHTVejjZ+vfuwkNfX4W316yGFE/9JiSbyYBlVeVYNbsBbQV2GE/SiKfVYcN+/5SqvveH9U1OoTzXkvX1AQyCgHZvAOMR5X9WJafAccC+QBDdKnoCzHbaUGLRbo8EYwwVuRZcUFmK2vxcjIUi8EZTXmmQAWy+APHzTU6Ht9M7oZ9uXlmKEgCd+cq3734IiZ8k0KVQwI+19/8Uj/3425gYHU758wrNJlxVV4WbWhswy2mHcYa7zhljmFvowObRcYQSqKi21+fHkuICWLK86I0/GsNeFVUBBQBLSrP7OKA3EsWOceUlgWtseajXQXLEAJRac3BueTFmOW0IxOIYDqW8AaCFMaxsdtovmlXoeJtOC6QOJQA6sm8iuoRx9h9ax5EKW597Cr+/4/Po3PQGkOLKZMU5ZnyksRafaqlDgy0PIlO+mmoSBNTb8/DmwTHV+wFisoy+ySDOLC0CUxFDpjCLoqrGN75oHMtc5RCy+M9G4jJeV3FUsjjHjLk6W0IqyDFjSUkhZjltGJwKw5fqGQGGGg58vqnAYay0Od/q8fmorHCSZfdB3AwjysKdWseQbP7xUTz0jS/gz3fdjsC48jdCJfKNRny43oX/OH0eziwtTHhgqc/Pw/UN1Qndo2MigBcGDiZ0D72ryrPCoaIPQkSS0KejPvepUGZRtwQ0HEz5p2zVGu35uHPhrHQlbmYGfne+Qdq1vNl1XjoeeCqhBEAn2n28jgNXax1HMm17cT1+duNl2Lnh+ZQ+J9dgwMqaSvzojHm43FUOg5C8N6aLKktxpoLmLMfyVM8ADkyFkhSR/jAAs5x2Vdd2+LRt5pRqVqNBVYno4bSX7VVGYAwllvQ1JuNAA5OxYUVD1X1XNDae2h3RkogSAJ0QufQ1ZMmSTGB8DA9/84v447e/hGAKm/aYBRGXu8rx4zPmY2Vt5TF39SfDx5tqUZpA0Zq4zPHnfd2Q09+UJW3aCtQlAO0q9g5kmlKr8vHKG44gKqWzXK9ypda0b3AVwNhtAiJbVzRXnTI1UlKJEgAd2D3BCwB8Wus4kmHLs0/ipzdcih0vP5eyZwiM4fzyEvzojPn4cL0r5celzKKIVbMaVe0lOGx/YBIvHMjepYBmx4l72B9Pl38S8SxOjACgNEd58sgBjKZ+s11CylT8vpKBAbMhs40rGl0/ptmAxFACoANGLt+EmZcN1qWgfwJ/+Nat+Mt3v4qgX/mu55lqddjw3dPa8PHmWthM6dtdX51nxTV1VQnd46nuAQwFs3MpwGEyqpolmd4HoL7mQiZQ+0n5YEjfywBqZjaSyADg2yKLvLOysbpNy0AyGSUAGuOcM8blz2sdRyJ6dm7Ff31yJbb/M3XV/JxmEz7bWo875reiUqMyu8sOlQxWKy5z/DGLlwJaHPmqrtvny/YEQN1AOaLzGQANlgCOxjGPg29e0VT9b6DKtopRAqAxty9+PsCatY5DDVmK49kH78P9q26AZ7A/Jc8wCyJW1lTih0vm4SyNz4wzxvC5WQ2qNnUdtt8/iX8eSH0NBC202NUlR50T2b0PQG1Bn/SW4lUuWS2LkyAHnN+7otH17GWzasq1DiaTUAKgNcZWaR2CGmP9Pbjvpuvw3O/uPdS1L/mfas8sLcIPz5iHlbWVMy7ik2p2kxGfaq5N6B5P9QxgROfTu2o0JbAPgGfprAgAlFpyVH00HQvrewbAYTKqOnHDUvdBfZkxJm9d3ui6LFUPyDb6eFc9Re3180LI+LDWcSi1c8Pz+O9PX42+3duPGPaT90NdYjHj9nkt+Fxr/VHNevRgQZET55WXqL4+Ksl41N2bxIj0wWEyolTFufdQXMJBnU93J8IoCKq+jz2RlJfeTQhjDAVm5bMAVqOIOSpPjcxAGQOeWdFQdd+iRYv09+ahM5QAaMggyZ8EQ8Y0RZelOJ7+35/hoW98AaHA9LRtMnN5A2O43FWO7y2ei9kqz5Wny3UNLhQkMAW6y+PD1jFPEiPShxanur2s+/3ZvQ9AzfeKJxxNwbxacqlZBpiKxfGF2Y348pxmOM2mFEQFBsZuq5gYefGqFldFKh6QLSgB0FbGbP7zjQzh/lU34p9/fCAl92+25+O7i+fiw/Uu3Uz3n4hFFPGZ5rqEEqC/u/sQkbKrBXq9Td1GwES6L2aCghzlA11MluGPpr5ZViLU7gMYD0cxr9CB7y2ei4sqS1NSVZADS2UJ265qqr406TfPEvp/p81S+yaiSwCeEcdX9r75Cn7+seXo2Zn85lxWowGfba3H1xbMQnkCxXa00Oq04eyyYtXXeyNRPN0zmMSItNeQr3YGILsrAhapmCoHoKrLYjoVq6wGeHiDo9Ug4iONNfjmglkoT82pgmKZ82dWNri+AzolcBRKADQiyOwjWscwE68++jB+/9WbUlLRb06BHd9bNAdnlRZl7E/m9Q3VCU1jvnjgIAamsqf1eYk1R9UpiYPBMKbi2dvrRe1ykSek730AhWp/Xx9IbOptebhrURsuT01zKJEz/HBFY9VjKysqtDlDrFOUAGiAc84Adq3WcZxIPBrF377/TTzxX98/tMs/eRgDVlRX4ra5LalaA0wbq0HEJ5pqVV8vcY5HOnt1v9Y7UwxAvS1X8XUcQI8/exsDFalYAgCAMZ3PABSq/H35IkcvbRgFAR+ud+GbC1M1G8iu41bxjZX1FYl1+MoilABoYL83fg4A3X4TBsbH8OtbPop31q5Oyf05B147OAKPzs85z9TcQkdCNQrcEwG8PZzaTonppLaPfe9k9iYAaj8p+3R+EkDNKQBgevnreOrz83DXojmpahU9H0x868qmqjOSfeNMRAmABiTGbtA6huPxDPbjl6uuR/eO5K/3H2kiGsN9OzsQjGXHtO8NjdUJFQj6v/0Dum/+MlNqE4D+LE4AClTOdB3rk7Ke2IwGVT0yvNETJzZGQcB19S58Y/4sFCZ5lpAzlAucvXRlQ9XlSb1xBqIEIM045wIDdDn9P9zjxv2rbsRYf09anjcUDOE3e9yIy5k/AZ5rMOCaWvW9AnzRaNY0C6rNzwVTMSj0BbJnL8QHmUURFhXdKidi+p4BYIzBpqLGgTc8s8SmwZ6Hu0+fm3BL7mOwCow9taLBdWOyb5xJKAFIM7cvvhSA7s6m9u3ZiftX3QjfyFBan7vP58fD+/ZnxRr4eeVFqo/BAcCzfUPw6fzY10zkiCJKVHSKGwtHsnojoM2k/JOsL6zvBACAqn08SpY2LKKIz7U24ObZjbAak9oAzASGvy5vqL45mTfNJJQApB27TusIPqh31zb8+paPYcqnTWGaTSPjeGJ/anoJpBNjDJ9orlHdNjgiSVjbcyDJUWmjJl/5ZmsOoD+Qnd0SAcBhVv5JeSIW031y7FTx+4rIEoJxZZuLFxcX4DuntaleYjoOkTH+wIpG15eSedNMQQlA+l2hdQBHGuxsx4P/9llEgtoWYnm2fwgbD45qGkMyVOVacX6F+jLBGw+OZsWxwGqVHRt7p7K3IJCacsBxmSOo81kRh4qZDUDdBsfiHDO+sWAWVtZUqlpmOg4G4P6VjVUZU5gtWSgBSKOOMT4LQL3WcRw22teN337lUwj6fVqHAgB4pLMX3VnQG/7quirVPQxkzvFYV+b3CajOU7kRMIv3AaiZAQCACZ1vBHSoPAqotsqhyBhW1lbiS21NyVwSYBzsgeUNroyoz5IslACkERNl3ew69Q0P4te3fBz+8eR86s41GJCjYpPTkWKyjN/s6oTvJDuE9c4iiri2Xv0pz3ZvAHu8E0mMKP1q8q2qijsdCGbvEoDNqG6gnND5vhCHymQ3EEvs9zWv0IHvnNaGmnzldSeOQ2QMfzyVuglSApBWXBfT/9FwEL//2qqkbfirz8/D3Yvn4Pb5LQknAb5oDL/d44aU4e1hzygtRK2KgjiHPdE9oPu13xOxGERVdeIPToUy/u/+eNTOAPh1fhJAbWLjT8IR4OIcM+5cMDuh7pwfYBKAvy9vqpmVrBvqGSUAabL9IM8Fx3lax8E5x6M/uBMH9u1Jyv1OLynE1xa0wmk2oT4/D7fOaVK9Ce6wrolJ/LmjOynxaYUBuLG+RnWJ497AFHaO62NpRq1KFfsAJM4xGsqOAlEfZFNZJ2Iqpu+GUTaV0/CBJM1sGASGTzbX4hNNdTAkYV8AB+yMy+uuaEyg0UeGoAQgTSwm6UI9tP595oH/wbvPP53wfRhjuLbehVWzGt7Xva/VYcMnE+ySBwBvHBzL+E2BDfY8LChyqr7+ye4B8Az+NFyRq665y4Gp7FwGyDOpGygndV4sK0/lEkAyZgCOtLSiGF+Z14JcQ1L2BdSJMD62aNEi9dW9MgAlAGnCGDRf/29/81W8+PD/JnwfkTGsmtWAy1zlx/z62WVFWFlbmfBzHunszfgd8dc1VMMgqEuHBqaCeHc8+U2Y0qVSZXe3wWBm/50fj9qBSe+1EfKNBlU78gMp2Oszy2HDnQtnq26+9AEXlE8Mfz8ZN9IrSgDShfGLtHz8pGcMf/uPryf8idIsiPjynGYsLi444etW1FTiggSOwwHTmwJ/t6cro0vkFueYcX4C65Nreg5k7CxAucoZgKFsnQFQO1We4Ga5VBMYU5XcBFI0s1FmzcG3F85GVW4yGv+xby5vrr4kCTfSJUoA0mCvnxeCs1atns85xyP3fD3hHf9WowFfm9+KtgL7jF5/Y2PNjF97PEPBEP7mzuxjcStqK1UfVxqcCmHTqDYFmhJVbrWo2g+SrUsARkF433LZTE1F9T0DAEzPAiil9hjgTNhNRtwxv0V1PYojCEzmf1zZXKG+25eOUQKQBoa4dDagXcv7Nx7/C/a++UpC97AaRNw+p0XRznaRMdw8uxHlKqeCD9t4cBRvDY8ndA8t5RoMuKzq2MslM7G29wDkDJwFEBlDsUX5VGyqPhnqgZpZgEmdLwEAUNUPYCrFf895RiO+Or9V1WbUD6iALP46GTHpDSUA6SDws7V6dGB8DOt+/YuE7mEWRNw6p1nVsTaLKOKLbU2qGqEc6a+dPRgJhRO6h5YuqipBvspNYMPBMLaOZeZegEoVywCiZqly6qmZKp9SWDJXC3lG5T/fYUlK+ZHPXIMBd8xrUb0h9TAOXL+8qWZ5ksLSDUoA0oBxdo5Wz15z348RCvhVX29gDLfObUKzXX2Tm3JrDm6e3ZhQb++IJOGh9v0Z+UkYmE6iLqtS3wPqmb6hjKwLUJevvCKg2r0DmSDPpHygzISW2RaD8hkAjukkINXyjUbcPq9FVdOiIwlcvu+C2lrNT3IlEyUAKbaZcyMHFmnx7K6tb2PLs08mdI+PNtVglsOWcCxtBfaETwbs90/i+YHMbZl7YWWJ6rrp/ZNTaPepT+S0sqCoQHHid/pJNphmMquopnGOrPvkL1flDF+6ahw4TCZ8eU4TzAnMRHKgIc8gfyuJYWmOEoAUs3tiiwAkYzuqYmvv/1lCO8iXucqTWWELV1ZXYGEC5+IBYE3PQMZuEjMKAi6vVr8X4NnewSRGkx4lFjPOUVBPpdSag7OzuP5KjkH5Wy7nHNE0fFJOhEXFEgCAtDY6cuXlYtWshgSbCPGvZ1OBIEoAUk0Qz9LisXvf2IDeXe+qvr7Zno8P1VUlLyBM74L8TEu9qhKxh8Vljofa92dsudjzK0pQqHIqcq/Pj57AVJIjSr0bGlwzauGaazDg1rbEK0nqmdpPoCGdH4W1qqxxEErz/oZ5hQ5ckUASDiBX5KavJyserVECkHJ8oRZPfe5396m+NtdgwOda61PyRmwxiLh5VmNC9+6fnML6DPw0DEzvjL+iRv1egOf7k9O/IZ3MooivzmvB0ori4y4HNNnz8e+L2hI+MaJ3OaK6t9yIzjcC5hpULgFocMLhqppKtCayrMn4lz7UUJq8qVENUQKQcmxeup/Y8c4b6N21TfX1n2mtT1YlrWOqteXiw/WuhO7xTN9gxlYJPLu0WHUHta1jXoxm4GkIsyjiE011+P7p83BtgwtnlxXh9JJCLK+uwJ0LZuMbC2ahOIXfc3qRI6r7pJyOzXKJsKicAQhq0OdAYAyfba1P5GRSblQw3ZbMmLRCCUAKvcy5AeBpLwD05pOPqL52UbET8wsdSYzm2C6pKsP8BPYDxDnHnzq6M7JKnkFguLiqTNW1Mud4M4NrIpRYzLisqhyfaanHqlkNuLquCg125ScFMpXqGQBZ3wmAVeUegLCkzQkHp9mEqxNY4mQcN2VDnwBKAFLI5Y22Akjrx5rghBe7XnlB1bUWUcSNjTVJjujYpvcD1KneFQ8APf4pvJqhDYOWVpTAqnLadK9vIsnRkHRRuwcgHNf3HoAcQd3vKyJr9/u6sKIE9TbVx5vLKiZGrkxmPFqgBCCFZIhpn/7ftO7/EFfZZOOy6vKEBmSlcg0GfLa1PqESiU/s78dECkuKpopFFLFUZa8EfyTzfr9kmppTAAAQk/U906U2sYlqmNgwxnB9IkuRnK9KXjTaoAQghZjA56b7mTtefk7VdXlGIy6qLE1yNCc3y2nDeRXqT9UE4xJWd/UlMaL0ubiyTFVt+ByVMwdEe2r3fqidYk8Xs8ryjVovbTTY8zBX5ZInZ+zS69uKM3r9ihKAFOJp3gAYnppUffTvclcZchIs16vW9Q3VKLaoL7D1zsg4do77khhRethNRpxVqrzHSL2K6npEH8pzrYrbQwuMJaOpTUqpnQGI6OB448oa1QXKTOGo5YIkhpJ2lACkkMAxO53P69z0BiQVx2qMgoBzyrWrbWEWRHyquTahAh2PdfUjnoEbApe5ymFQ+Ps+U0XSQPTBIopYoHDz69xCh6oeAulkFARVR3v1kADU5ueqTqq5LF+a5HDSSt/fVRlsM+dG7pMSO+um0L63XlN13aLiAs3fYFocNlxYUYKXDgyrun44FMKrgyOaLGMkosRixkVVZTM+37+4pECXu+YjsoRoXEZYlhGKS4hIEiKS/N7xtagk4cjl3jiXET3OBjADYzAdsamMMf7eMTOTIMAkCrCIInJEEWaDALMgwpJByyLX1Lqwa3xiRkf7TKKADye5IFeqmAQBIYXHFbVeAjhsaUUx9u+bVH4hw7LkR5M+lACkiG0CLgBpfVfq3rFF1XVnlBQmORJ1PlznwvYxL8Yj6jYxruk9gDNKCzVPZpS6pq4KgWgMbw6PnfB1TfZ8fKq5LuXxhOISPJEoJmMxBGJxBKIxTMbjmIxN/y8Qjb3364gspb2a2/GYRRFmkSHXYECe0Yg8owH5RiPyjQbkmYzIM4rIMxhhMxmRbzLCbjJq0qO7xGLGzbMb8cCeTkRP8AnYKAj4fGtDxhRHMonKEwC91DdYVFyAv3T2IK54syVr/VBrZeET7Qcy8mxuZr1TZhAR8To5jW8vnHOM9fcovs4kCmh2qO/0l0wmUcCNjTX49e5OVdcHY3Gs6x3EDQ3VSY4stQyM4TOt9ajNz8Wz/UPwfiABMosillWV4YrqCsXrxx8kcQ5POILxcBSeaBSecASeSAy+yKH/FokiopM3ZaWmZx0AfzQO4OTFkgwCg9NkgtNsRkGOEQVmM5w5JjhNJhTkmFBqyVG1SXMm5hTY8a2Fs/GYu++YTZ4a7fn4aGMNXDpf+z/S9D4AZSdUYjpYAgCmY2+056Pdq7zhViyOZgBvJj+q1KMEIEVksNp0Pm9i9CCiYeVNcprttpS9yamxoMiJ+UVObB/zqrp+w4FhnF9eglJrZnXtZAAurCzFeRUl2O+fxEgwhKjMUZxjRqtT2d8RB+AJRzESDmM4GMZIKIyRYAjD4QjGQ5GM3CuRCnGZYzQcwWg4AhyjtAID4DCbUGo1oyTHghJLDsqsOSi1mlGUk5NwqeyqXCvumN+K0VAYnROT8MdisJmMaLDlotSSGZ/6j2RUkZzqqadHm9OuKgEAF5tACQA5EuO8lqdxBmC0r0fVdTU6/ITxscYatHv9qj6JxjnH4939uLWtKQWRpZ6BMTTb89Fsn9mszFQ8jv7JIAanQuifDGJgavrXMQ0LrGQLDsAbicIbiaIdgfd9TWQMJRYzKnOtcOXlojLXgqpci6oS2sWWnIROweiFmoRIT8loTV6uquu4wJuTHEraUAKQIhysNp3P8wz2q7quVIfri06zCVfVVqo+379tzIuuiUldbpZLhC8aQ49/Et2BSQxMhTAwGTxquYCkh8Q5hoJhDAXD2Dzqee+/WwwiXLm5qMqzoCY/F3X5eSi15miy1yDdDCpmEuM6WQIAoHrWkHGkfmNOilACkDpp/aaIRyOqrivKSV/lPyUurizFxoOjGJxSvqwBAGt6BvDV+Wlvw5A0EVlCXyCI7kMD/n7/FA32GSAUl9Ax4UfHxL+mki0GEfW2PNTl56HWloe6fCvyjRlfRv4oSo+zAvqaAXCYTTAITM1GwIztYkUJQOqk9eyOrHLjlp7W/48kMIZr61y4f1eHquv3+vzY5/OjJZG2n2kUliR0TEyi41DcA5NBXa2PEvVCcQm7PRPY7fnXRoMSSw6aHTa0OPLQ6rDDrrJCoJ6oWQKQdPQtzgAYmYA4lL2XcvCMHUczNvAMkNbKOmoKAAHqsvZ0mVvoQFuB/X1vnEo82TOAOxektRbTjEUkCZ0TAezzBdDhC6BvcooG/FPISGh6c+brQyMApqefWxz5aLHb0OSwqS4ZrCVVmwB1tldFUPF+KHBKAMgR+vu5JQwprbvruMqCGlp245qJGxqq8X3vLlWDY9fEJNq9frQ69TELMBQMY+e4D7u8PnT6AjTgk/cMB6dPbLw6OAoGoCovF3ML7JhTYEe9LU/VwJRuopo9ADr6GeDAcYtTnfA6xvQ5jToDlACkQMSKtNdqzXUUqLpuPBxBvU2/m+XKrRacU16EVwfVtf19sucAvqVRAhCTZez1BbBr3ItdngmMhdXt0yCnFg6gf3IK/ZNTWN83CKvRgNlOG+YWODCnwK7b/QPqlgD0kwAEonGVp2f4iSt46RglACkgC7FCluY2C45SdQ0txsL631h2VY0Lbw97VB0L3O8PwD0RQOMMj9UlKirJ2OmZwJaxcewcn8jYojpEP4KxODaPeLB5xAOBMTQ78nBaUSFOKyqAzaSjt3AVkxT6Gf6BsfDJi0cdC2csM9uRghKA1GCsKN3f2c6yclXXdU34Aai7Nl1sJgMuqizBM30zq5f/QVtGPSlNAGKyjL1ePzaPjmPbmE835U1J9pE5R7s3gHZvAH9z96LelovFxYVYXFyg+UZCpioD0E8K4J4InPxFxyJTAkCOIIAVpvvb2llWCcYYuMIfqH2+SUicJ1zVLNWWucqx4cCI4lrjAFQfJTyZ3sAUXjs4gneGPTTok7TjnKNrYhJdE5N4rKsP9bZcnFVSjDPKCmAWMqM5kn6Gf2CPmiqAADhkSgDIv3CZFYGl91vbYDKhpLYRw93K6uhHZAl7vROYU+BIUWTJkWsw4OKqMjzde0Dxtcn8mxgNR/DWwTG8cXBUddOiTGe2WJDvcMJeUACbswC5+fnIsebCbLHAYrUi12aH2WKBOScH1nwbLFYrxCPWrQ1GI3Is/9ojyxiDKIqIH3GSJR6LIhw6InHjHJN+PyKhECKhIIJTUwhNBhAJhRAOhTDln0A4FELA54Pf68HE+BiCkyq6u2WoI5OB/+vuw+KSApxVUpx1xbBSZSoeR6fKGQDJJG5PcjhpQwlAamiy66xx0ZmKEwAAeGVwRPcJAABcWlWGfx44qLj7XKGK8qxHkjjH9nEvNhwYwT6fX1efWpLJWVyMwtIyFJaVo6SiEoVlZSgoKYXNWQB7QeF7A745Q+rUx2Mx+L0e+L3eQ0nBOLxjoxgbGsT48EGMDg1ibGgI3pHh9yUfmS4Yl/Dq4CheHRxFqcWCCytLcGZpEawpbpmsdg6RJ3BtsrxxcEztBsD25/b2qlub1AFKAFKByWYtvqWbFp+Fjf/4s+LrdnomMB6JotCsz6qAh1kMIpa5yvFU94Ci69oK7KqeF4jF8PrQGDYMDmdFFb4cay4qampRUVuL8ppD/6uuQWFZOYrKymE06fvvXymD0YiCklIUlJSe8HVcluEdG8Xo4AGMHDiAod4eDPZ2Y7CnG4M9PZjwZGSnVwDAcCiER929eKJ7AGeVFuLCyjKUp6hRlqo9ADogc45XD9VjUIqBvZzkcNIVb7yyAAAgAElEQVSKEoBUYDBp8TGx4bQlqvYByJzjyf0DuGlWfYoiS55LqkrxxtDodAe3GSiz5mBhkVPRMw5MhfBC/xA2jXoysqmOvbAQtS2tqG1uRXVTMyrq6lFRW4eC4hKtQ9MlJgjvJQotC0476utTgQAGe7ox1NuDvs4O9HbuQ0/7XgwP9Cv+WdNKRJKwYXAErwyOoMVpw6WVZZhT6EjqkK16GxHnCVycuDeHxzAcVHcCQKYEgByFQ5OPUnnOQtTOOw3d27covvadkTFcXFmKWpu6jljpYhZEfLq1HvfuaD9pzW6zKOKm1oYZb3DsDkxifd8Qdox5M2KaXxQNqGluQUPbHNS0tKKmuQV1La2wF6a9DEVWy83PR9PceWiaO+99/z0cnEJvZwd697WjZ187utv3wr1rJ8LBKY0iPTkOoN3rR7vXD1eeFVdUV2BRkRMsCQOwmo3EWm8+jkiS4hnFI4SMceGFZMaTbpQApIR2zSHOvOajqhIADuCv7h7cuXC2rssDA0CzPR9fmzcLv9nTAX/02Gu3hWYTVs1uRE3+yROadp8fz/QOYq9P3S7gdCmvqUXzvAVomjcfzXPno6FtDkw5md9GNlPlWHPRMn8hWuYvfO+/yZKE/i43OnduR8f2bejYsQ29+9p1ucegfzKIB/e4UWqx4IqaciwpKUzoZ9+pYgnRYTYmJflQ68nuAfiiMbWXr36yp8eXzHjSTd/v9BmqwxP/LWO4WYtnR8Mh3HPlmQgF1A1mV1SX40N1riRHlRoRScIbB8fw7pgXI+EIZJmjLNeMhYUFOLu86KRHofomg3i8q0+XA78oGtDQNgdzlpyJOUvOQOtpi5Bv1/9GTXK0aCSCrl07sfOdt7B709vYs2WzLmcJSq05+FBdFRYWFagaGDomAvjFtr2KrjmnrBifbtGmm+5erx/37mhXPdvHBSxd19H/WlKDSjNKAFLA7Y0/zIHPaPX8x//ze3h99Z9UXcsYw1fntqLVmZ7KeVoYj0Tx5P4BvDM6rps1XFE0oHn+/EMD/pmYvWgxcqz6Xo4h6khSHF27d2H3O29j5ztvYdc7byM0pZ8ji/W2fFxXX6W4eBYH8OOtu9EbmFlywxjDd05rQ3VeWtumAAD80Th+sGUnJtR/+t/7tLtfn53GFKAEIAXcvvgjnOOjWj1/tLcLP73xcsiSumlHq9GAOxfMTtluYa1EJRlP9x7AiwcOquj5nXxF5RU47bzzsWjp+Zh/1rnItemjaRFJr3g8jr1bNmHrqxuw9bVX0d2+RxeJ6cIiJ25sqEaBgmO0/ZNB/GzbHkSlk2+evbK6AtfUpbVrOoDp2ie/2NY+40TlWDhnX1jX1fdgEsPSBCUAKdDpif8dDDdoGcNjP/kO3vy/R1RfX5RjxrcWtumr1ngCdngm8LeObk2L9wiiiNmLTseSiy7BoqUXoLqpWbNYiH55Rkfw7muvYNPL/8SWVzYgHApqFotZELGythIXV5XOeMPePp8fD+x2Y+oE+x6WucpxbV1V2tf/Jc7x692d2DmeyNI9b5+sGpi7YQP0t7FDIUoAUqDTG/8zgE9oGYN/fBQ/+tCFiIbUZ7muPCtun9ei2+5jM+GLxvB3dw+2jHo1eb7BaMT8s87BWcsux5mXLKMd+kSRaDiMra+9gjeefwabXv4nJicmNInDlZeLTzTXoC5/ZpUFJ2MxPNd3EJvGPPAcOrJrFATMLrDj8qpyTSoUypzjT/u68cZwYs37GMeH1nb1P5mksDRFCUAKdHrj/w/A57SO45nf3ovnf39fQvcot+bg9nmtqnb4am37uA9/3NeNyZjqdT5VRNGAhectxdIVV2HJhZfQ1D5Jing8jp1vvYHX1q3FxmfXpb3UscgYVtRW4gpXOQQFn9zDkoSIJMNmMmo24MRkGf9v735sHfMkdB8ObFzn7j83SWFpjhKAFOj0xX8Njlu0jiMaDuLnH1uOsf6ehO5TaDbhtnktKLdmRgnYmCzjH/v7seHAcFrP8zfOmYsLr7kWS5f/f/bOOrqOavvj3zMz1+LeJo022tSNKm0K9bRFSqG4PvjBQx/6cHi4u7yHQ6HQUupu1N1SjXvSuF+f8/sjFApUcs+duTM3mc9aXbDae2b2lTl7n60zEBSm/Em/4PhRHNi6BdXlZdDpDYju2RNDMi5GcHi40qJ5DZRS5GYdwsHtW1FXdRIGkwkxickYkjEOAcEhislls1iwY+1qbFy0APs2b4KTMd+HhZTAANzaq6fXHAraHE58fCQHJ9yv9rFx4IYvzi3aL4VcakAzAGQgt97+DgW5T2k5AKAwax/e/8dVzAmBpzDwPK5LicOwCOUV27koazXjs+N5KGvxTNw0IDgE42deifEzZyEmKdkj9zwfhSeO49PnnsLh3Tv/9m+CIGDCrNm46ZHH4eOnDYo5FycO7MMnzz+N3KxDf/s3vcGAadffjGvvfxB6g2JtPwAAjbU12LhkEVb+8B1K8/M8ck9fQcANqQkud9n0NCUtrfjsWB4qGDv9/Rny+NLc4pcluJBq0AwAGcits79GCXlYaTlOIUUo4BRjIiMwKzEGBl5d40YpgPVlJ7Egv8Qj7XtTBwxC5rU3YNSUTMUVwOns37IJL/3zjvPWmccmp+CFr3/QvAFnYcuKZXjroftgt507aTS1/0A89+V38PVXvmyWUoqsHdux/PtvsHPtao80HxoTGYErE2Oh5znZ7+UKFMC60kosKCiRpuKHYrMpr2TcPKBTzf3WDAAZyK23/4eCPKm0HKcQnQ68e+sVKD4izdTKYIMeVyfFYYBKrP+KNjN+yC3CccZ53h1F0OmQMeMyTL/hZvRM7y3rvVgoLyzAA5dldjg2nDZwMF79YT44lRlzSpN7OAuPzr4cNmvH5k0MHXcxnv7vlzJL5Rp1VSex4oc5WD7nGzTVuxf3Ph/hJiOuTopVzUTRijYz5uYUSdngq4nw3IAlJ4oKpLqgWtCefBm457FnLwQwTmk5TkE4DqnDLsSB1UthdaMq4BQWpxO7q+tQ2NKKSB8TAvXKVAm02O2Yn1+Cb7MLUW3u2GbNgsnXD9NvuAkPv/0BLrp0JoJVOlTn/SceRcGxox1+fU1lBbrHxKJnL/UZM0ry6n13obKkuMOvLy8sQHLffuiRoJ5hWiZfP/QbPgKZ192A4LBwlOTloLWZbd79+WhzOLCzqhalrW2I9vNRrGqo2W7Hz7/tB1UdHBbWAURCcfWSnOIdUl1QTWgeABnIbXA+RCl9XWk5/krJscP44I7ZbpUG/hUCoG9IIKbE9vBYaU+V2YoNZZXYWlkDi1M+j5xfYCAuu+V2TL32BvgFso0U9hSNtTW4YdRQiC5+Hr0GDcZrP/4ik1TeR0leLu6afJHL64ZdPAFPfvK5DBJJg8PhwOali/HjR++jrEC+PAFCCAaHB2NKTCRi/DzTybLKbMWmiipsLq+CWeL9gID8e0lu8SuSXlRFdI4uLyqDUiqvz42RmF59cOPL7+PzB//hsqI4GxTtTXYO1TUi0seEkZFhGBYRhiCJvQJWpxNZtY3YUVWDrLpGWTulGUwmTL/hZsz8x52qV/ynOLJ3N9N3evzAfthtNuj03pHRLTdHzpA42REO71L3AVEQBIy79HKMmT4Da+f/hLkfvIuaygrJ70MpxZ6qOuypqkNPfz+MjgzDoLAQ+OikVTU2p4ij9Y3YVFGNI/Xy7AeU4tOleZ1X+QOaASAX7nWakJH0UeNwxSPPY94rT0r+0FS0mfFzXgkW5Jci1s8HvYIDkB4UiFh/X/gIrkWbnJSiuKUVBU2tONbQhKN1jbIn93E8j4mzZuPqe+5HSEQ3pmu0NDZi68plyNq5A/U1VTCafBCbnILRU6YhsXcfiSX+g4bqaqZ1VBTRUFON8KgeEkvkHo21Ndi8fCmO7t2NxrpamHx80TO9D0ZPyZS1g2J9dRXTutbmZljNZhhM6i6V5XkBk666BuMuuRxLv/sKP338AVqb5MmdyW9uQX5zC+bkFCEp0B99QwKRGOCPWH8f6DjXkgadlKKizYychmZk1TXgREOz3PvBjz55Jf+U8wZqQAsByEBunX0UJWSL0nKci+2//ID5rz4lmSfgfAQb9IjyNSHcaICPToCvIPw+rc/idMJJKRptNtRarKi12HDSbPFINv8pUvoNwF3Pv+SWkl45dw6+fuOVs3ZrGzFxMu5+4RVZ6sc3LFyAtx6+n2nt3H1HVJHFDrSfIH/5/FP88P67Z6xkIByHjBmX4s5nX4DJV/qQ08Iv/ofPX/6Py+sEQcCCI7kgLio2pWmoqcEXr7yAjYt/8dj8AYEQdPM1IcxoQJhBj0CDHkaeh44jIITA4nCizeGAxSmizmJFeZsZVW0WODw2H4H8bDL4XzPvyBHl+oZ7CM0DIAMOQajhPaRYWRlx2dUw+vpjzrP/gtMDnfLqrTbUK9iH/2z4BgTghgcfxZTZ17q1eX/12sv4+X8fn/M121evRMGxo3j1xwUIkTiRMC4llWldWGSUapQ/0J7IuGbe3LP+OxVFbFi4AAXHj+GVOfMk77LI+jnGpqR6nfIHgKCwMPzrjXcw/oor8fEzT3ikj4CDUpS1tHmsV4dr0G9NuSU3d7Zyv7Phfb9YL4CqOARwOgMnTsOtb/wXeqO63ZZykTZwMN5dtAJTr7nerc1709LF51X+p6gsKcar994p+WkroVc6ouJdn6s+ekqmpHK4w9Jvvzqn8j+dwuPH8Paj/5Jchr7DRiAwJNTldaOnTJNcFk/Sb/hIvLt4JabfcLPHB/SoBkrfG5JbelNXUf6AZgDIQpo/6uElP6JeIzNwz//mIbRHrNKieAyeF3DdAw/h1R/mo1t0jFvXcjgc+Op115qDHd2zG9tWrXDrvn+FEILr7n/IpTU+fn6Y+Q/FO1YDAMytLfj+3bdcWrNz7WrJk+8EnQ6z73atiWdweDimXX+jpHIogd5gwO1PPYenPv2CyQjyVghgB6W3L80rve9ZwHNxRxWgGQAyQAgRAbgzb9KjRKf1xoPfLkGfsROUFkV2IuPi8erc+bjqrnslaYBzeOd2VJeXubxuw6IFbt/7r1yYOR2TZ1/boddyPI9/vf6OKmYWAMDuDevQ3Oj6I7NhkfQljJnX3YiRk6Z26LU6vR6PvvexLPkISjF03MV4b+kqDBh1odKieIJiQByzNK/0f0oLogSaASAb9KTSEriCyT8At7z+KWbc+xh4oXOmhkyYNRvvLV6B1AGDJLtm9sEDTOtOHNgnmQync9dzL+Kqu+4Fz5/9OwwMCcXTn36BYeMnyiIDC2r6HAkhePidDzDt+pvOGRoK6x6JF7+Zi95DLpBcBqUJCY/A819+h5sffRyCF48DPxeEYoFOEActyS1Tdw2njHTRYI/85DQ4loNiitJysFCRl435rzyB/AN7lBZFEgKCQ3D3C69gxMTJkl/7s5eex6IvP3N5HcfzWHgsX7Z4a2l+HpbP+QYHtm1BVVkpDEYTouITMGLiJEyefZ3qBgG99fD92LDQda9IcHg4vtm2VwaJ2sk/dgQrf5iDQzu2obqiHD5+fojumYSRk6Zg0pVXQ280ynZvtZB7OAvvP/4I8o8dUVoUqagH6D1Lc0vnKC2I0nTOo546KFRaAFYiE1Nw939/wp7lv2Dxuy+hpb5WaZGYEAQB46+4Etc98LBsMU3/ILb+5wHBwbImW0X3TMTtTz0n2/Wlxj+Q9XOUdyRvz169cdfzL8l6D7WT1Kcv3lm4DBsW/YLPXnoezQ31SovEBAHsIPRLQbQ/9UveSbaGD50MzQCQCQpSSDw6jV5aCCEYmnk5eo0ci7VffoTtv/wAm8WstFgdZtjFE3Dzo0/I3p89uW9/j67rrCT30z5HNUM4DhddNhODLhyLOe++gbU/z4PDA+XDUkGBRaIoPrI8vyxbaVnUhBYCkImcBscsUPyktBxS0Vxbgw1zPsPW+d9JOktASgjHYWjGRbjstjvQZ+gwj9zTYbfj1oyRqKtyLeXj4bc/wJhpM2SSyvtobW7GrRkjXO5K98LXP6D/yFEySaVxNqrKyjD/0w+xZv6PajcENgL0uaW5pRuVFkSNaAaATOQ12oaKIrdLaTmkprWhDtsWfI/dyxagulgd0zFNvn4YP3MWpl1/E1MtvLus/+VnvP3IAx1+fUq/AXhj3kKvbBwjJ6524Rs8dhye/exrGSXSOB81FeVYOfd7rJn/o8tGsIxYCMh8keKdZXnF8iWIdAI0A0AmTjTRMM7pZGvQ7iUUHNyLXUvn4+DaZTC3yDNq9Gzo9HoMGHUhRk2eiuETJiveze7T55/G0m+/Ou/rwrpH4vWffkFYZJT8QnkZlFK88a97sWnpovO+tkdCT7z24wLZcwA0OobT6cCejRuwZv6P2L9lE2wWi6dFEEGxlRDM5R389wsLC72mDFtJNANARnLqHU0A1NNnVSacdju2L5yLn197Wtb7RPTogbSBQ3DBRRdj6LjxqstkX/TlZ/junTfP2MMeAAZdOBb3vfqm5G2AOxNUFPHDB+/i5/9+BJv1zDPdR06aintefNVrJjV2NWwWCw5u34pd69dg3+ZNqCorlfmO4mLOqb99cUGBalwQ3oJmAMhITr1zH0AHKi2HJyg4tA/v3TpTkmv5BwUjokcPhEf1QHTPRKT2H4jUAYMQHB4uyfXlpLG2Br8uXYysndtRd/IkjL4+iE9Jw6jJmUgfMlRp8byGmsoK/LpkIY7u2Y36mmr4+gegZ6/eGD11GpL79lNaPA0XaKytQfahg8g+dBCFJ46hqrQUJ8tKJJtCSECfWZJb+rwkF+tiaAaAjOTUO74GcIPScngCVgPgslvv+D0Zzi8wEEFhYTCafKQWT0NDQ2W0Njejqa4Wrc3NsFksKCsswHv/dq2dNaAZAO6glQHKCCEky1MjNr2V8KgoJPXpq7QYGhoaHsbX3/9PuTv+wcEKStM10dKQZYRCPKS0DBoaGhoaGmdCMwBkRLAJmgGgoaGhoaFKNANARhIiSCWALtFykmecrCc6vWJqsoaGhsw4HQ6mdRScqjsRqRktB0BmKJBFgIuVlkNuDL6+TOvMZymZ09DwdizmNpTk5KC1pRkBwcGITUpR3WQ9S1srinKyYW5tRVBIKGKSk885SVJOzK2MewEVPduEpBOhGQAyQ0APAaTzGwCMmfuW1jaJJdHQUJbS/DzMefdN7Fq35k+9DHz9/TF2+qWYfff9ipe0FmWfwJx338Sejetht9l+/3u/wECMu+RyXPXPe2UboHU22hibiVFwmgHAiGYAyAylZLeMQ99Ug8GHrSmPubVFYkmkxWG3o6m+Dq1NTWhpbERLcxNaGhvQ2tSE1uYmWFpb0dbaCqfDgdamRtjtdljb2mBua4PT8Ydn0m6zwWo+8zAlH39/cKe1BTYYTdDp9fDxD4Cg08HHzxd6gxF6gwG+AYHwCwyEr39A+38DAn7//4CgYK29sMJsXPwL3n/8kTM2MWptbsby77/FlhXL8O8PP/XYvIq/smbeXHz0zBNn7OHf0tiIJd98iS0rluKJj/6H1AGDPCYXsweA0zwArGgGgMzw4LeK6PxxboMPmweg9mSlxJJ0DIfDgbqTJ1FTUY6TZSWoPXkS9VUn0VhXh9qTlWisq0VDdTWaG72noyjH8wgKCUVAaChCu3VHYEgIgsMiENKtG8IiIxHePQphkVGKnz47K7s3rMPbj/zrvHktTfV1eP4fN+O1HxcgPjXNQ9K1s3Xlcrz/xKM4X3lyfXU1nrn1Brw5fxF6JCR6RDbmvYBw0nQU6oJoBoDMJIaQ4px6RwmAGKVlkROOF2Dy83d5JkBpfr5MEgHNDfUoLypEeWEBygsLUVFUiKryUlSVlqK+prrTJSCKTifqqqtQV12FwuPHzvo6vcGAsMgohEVGIjI2HpFxcYiMi0dUbDyi4hOgNxo9KHXnwGJuw/tPPNLh35S5tQXvP/4I3pi/CMRDLsLWpiZ8+NS/z6v8T3/9B088hpe/nyezZO2UFzDuBU7USytJ10EzADwBxTYQXKW0GHITFhuPkqNZLq05WVIEh8MBQWD/KVaVlaEkLwfF2SdQnJuD4pxslBcVoKWxkfmanRmb1fqbUVSAQ9u3/e3fw7pHokfPnohNSkFscsrv/9V675+dDQsXoL7atdlf2YcO4MjunehzwXCZpPoza+b/iOYG13Tl4d07kXPoIJL79ZdJqj8ozc9jWicSfY7EonQZNAPAA1BCthHQTm8AdItLctkAcDgcqCgqRExi0vlfa7ej8MRx5B3JQv7RI8g7egQludloa1F3HoG3UVNZgZrKChzctvVPfx8SHoHYlFQk9e6DxN590TO9NyLj4j12glUzezauZ1y3wWMGwJ5fGWX8db1nDIC8XJfXEIqKFXm5WgiAEc0A8AAccW6ltPMnZ4XHxTOtO7pn198MAEopygrycWzvbhzbvw95R7JQnH0CDsZaYQ33ORVeOLB18+9/5+Pnh57pfZDUpy96DR6CXgOHdMkcg8qSYsZ1RRJLco57FbPKyLbOFSqKClFXzdAyhZDj0kvTddAMAA9QEqg7GN3gbAGgrvm1EhMRy5YsdGjHdoy/4koUHDuGo3t349je3cjauQONdbUSS6ghNW0tLTi8awcO79qBhV/8D0C7pyB9yFD0GjwU6YOHIjG9d6evTmD1gnjSe6JmGQ+eIRTVESilJyQWpUuhGQAeYBwhjtx6xw4KjFdaFjmJTE5lWrd91XJcuWblWee/a3gXddVV2LJiGbasWAYAMPn6IbX/gHaDYMhQpA8a0ukSDbtFx6Ao23Vd1C06VgZpznKvmBim03y3aPnzl7N2shkAAD0iqSBdDM0A8BAiIasJpZ3aAIiIS4R/aBiaa2tcWmc/Qz2yRufB3NqCA9u24MC2LQAAQadD2oBBGDQmA4PHZCChV7rX5xEMybgIu9avZVg3TgZpznKvsRf9La+jo+vkxGG3Y/+Wzed/4RmgIBullaZr0bn9ciqCFx0rlZZBbgghSB48QmkxNFSOw27H4d078c2br+K+S6bg+uGD8Oq9d2Ll3O/Z4sAq4OLLrkBY90iX1qT2H4jeHmwGNOmqqxEY6lp3v77DRsieALhn43qXqxPaoVXL8ko0D4AbaAaAh0gMMWQBkD+bRkHsVgv8QiOUFkPDy2isq8WWFcvw4VOP4abRF+CByzLx9esv48C2LXA6vSPpU2804p//eRlcB4dimXz9cM9Lr3nU82Hy9cNdz73Y4Xv6BQbi7hdekVmq9hJKFigl6wB0rKmBxhnxbr+bl5FT7/gfgNuUlkNKWhvqcGjDKhxcvwL5+3bBbtPi+BrS4R8UjCEZ4zBqciYGXTgWOr1eaZHOya9LFuK9fz98znyWwJBQPPbBJ8q1Ap7/Iz56+vEztgI+RUh4BB7/6L+ytwJuqq/DTaMv+NM8gg5D6e1L80r/J71UXQfNAPAg2Q2OmYRivtJyuEtbUwOObF6PA2uX4cSOTcxjPDW8EwplNg6DyYR+w0di9JRpGDl5CoyMA6jkpqwgD3PefQs7162BzWL5/e99AwIwdvqluPru+xEUFqaghEBxTjbmvPMmdm9c9yfl6x8YhHGXtg8DCggOkV2O795+Az9+9B7LUpGnzvhFeeUlUsvUldAMAA+SU0sDwDlrAKhrJmgHaKmrQdbG1Tiwbhly9+7sdG10pUIvAHqewEcPcL89XQYdgXBasM3upCiu0zyX7uDj54cLLpqAUZOnYtCYDOgNBqVF+hunjwMODAlBTFKKWx0v5cDS1ori3By0tbR4fBxwW0sLbhk7HK1NrvfxISAbluQWy5ud2AXQDAAPk1Pv+BXAGKXl6AitDXU4uH4FDqxdhrx9u7qM0jcIBEEmIMiHQ6CJIMSHIMBI4Gsg8DUAfgYCXz2BnxEw6Tj4GgCBA0y6jj1OxXUi7v3J9THIl/TT4cIkAa02oMVK0WIFWmwUrRaKBrOIRgtQ3yqioY2iyULhEF2+hVdi8vXDBReNx+gpmRiScREEndfZ112Snz56H9++/TrbYoJbluaUfCmtRF0PdZmjXQKyEKCqNQBEpxPHd2zCriXzcHjTWjg7WYmewAHh/hwi/AjC/DiE+xOE+RGE+3EI9eMQ5gsYO6jIWTHb2U7/4f4ESREdSzIDgEYzRX2biOoWoKpZRG0LRXWLiOoWEVVNFHVtncMLYW5twa9LFuLXJQsREByCjBmXYsIVVyE+rZfSommchfrqaiz47BPW5WaLU8eWOajxJzQDwMM4HdyPvOB8AyqrwKguLsCuJfOxe9kCNFYrM6JXSkJ8CGJDOEQH8+geAEQFcogM5BDuz/3JHa8EZkabykfvmuCBJoJAE4/4UAD4u+FgcVBUNoqoaKQob6KoaBBRUi+iuE5kNlKUpqm+Dou//gKLv/4CSX36YvzMKzF2+qXaICOV8dlLz6G12bXJoaegFAvX5udrk74kQAsBKEB2vWMzAUYrLYfdasWRzeuw/ZfvkbN7W4fHhKoJgQMiAznEhnCICeaQGM4jMZxDiI96f9qbch14a63l/C/8C49MNGJkT8/Y7HVtFHnVIorrRZTUOZFXLaK0QYQX/kSg0+sx7OIJGHfpTAwem+GxGLfGmTmwbQueuvEa5vUiocOX55TulFCkLov2JCgAB/ITBVXMACg+moVtP3+H/WuWwWZuVUoMl/E3ECR345EQQhAfxiMuhEOPYALey7rIlTewBed99Z57nyE+BCFxPIbG8TiVs2qxUxTXiZi3z4bdRd6TD2K32X5vTRwWGYXxl8/C5KuvRWi37kqL1uVoaWzE+48/wryeAms05S8dmgGgALydm+fQOd/GmfyyMiE6nTi2bSM2zf0S2btcbweqBCE+BL0ieaR155HenUfPMA5epuvPSCmjARARoOybN+oIUrrxiAzgAHiPAXA6NRXlmPvhu/jpkw8weEwGZtx0KwaMVNwZ1yWglOKdxx5EVWnQPpoAACAASURBVFkp8zU40BclFKnLoxkACpAQQSpz6h2bAWTIfa+WuhrsXDIfW+Z9i4aT5XLfjhmeEMSHEfTqxqNXJI8+URwCTapKk5CM0nrX/eg6Hujmp47Po87shXGAvyA6ndi9YR12b1iHnum9MeXq63HRpZd3uiFFamLBZ59g59rV7Bcg2LIkp/RX6STS0AwApaDkJxCaIdflS44dxpafvsK+1UvgYOmyJTMcBySF8RgUy6NfNI+kcB56j/lDlKPVSlFc7/rpuXsgB7VM1K1nqB7Q8wTjewnYX+xERZO66hPzjx7Bh089hjnvvoHJV12LKddej5BwraW1lGxduRxfv/GqW9egovi0ROJo/IZmACiFjpsPh/MdAJL1NqWiiKyNq7Dx+89RcHCvVJeVjGAfgoExPAbGCBgQw8Pf0An8+S5yuNwJkUH/RQeqRPsDaGAwAEL9CG4f3d6sp6JRxL4SJ/YXO5BVLsLqUIdHoaGmBnM/fBfz//sRRk3OxOW33YGe6b2VFsvrydq5HW89dB8oyw//NyjFD8vyyjZIKJYGNANAMZL9SXVOvWMRgFnuXouKIg6uX4mV/30HJwtyJJBOenQ88MnVvjB08R4tWeVsm2BsiHoMgPo2199D0GlVGZGBHDIDOWT20cFJKbIrRewpcuBAmRP5NcpXGjjs9t/7CvQaPATX3vsg+o8cpaxQXsrx/Xvx4p23nXM2Qgdo4gU8JJVMGn+gGQAKQgn9H6GE2QCwW63YtXQe1n/zX9SpvCW23QnsKXZgVGLX/clRCuwoYJub0CdKHfGRVitFG0NEKch0Zm8PT9oTPXtF8rgeQE2LiN1FTmzLd+BIBZu3REqO7d2DJ2+8Gn0uGI4r77wbA0ertoeX6ti9YR1eve8uWM1mt65DQZ5ZfKJYvQlMXkzX3Y1VQHKgsDa3wZkHINGVdTZLG3Ys/BHrv/mvVzXt2ZzbtQ2Aw+VO1LS4rtH0PJDaTR0GQBljBUNwB/syhPlxmNKbw5TeOjRbKfYUOrE1344DJU5FWxsf3rUDh3ftQEJaOi695R/ImHFph0f/dkXWzJuLD596XIpxzvtao4s/QK4UUmn8la67G6sAQgjNrXN+SQl9oSOvN7c0Y/PcL/Dr3K/R1lgvt3iSs6/YgWYr7ZKxfwDYkM3WAjC1Ow+9Sp7UEkYDoHuA6yEMfwPBuFQB41IFNJopdhQ4sC3PgSwFPQMFx4/i7UcewM//+xiz/u+fGDvtEhC1ZGeqAJvViq9eewlLvpGkTX8Lxzuv2bgR2rhRmeiaO7GKKKii3R06ZzHOMSHQbrVgy09fY+3Xnyqq+PUCMDxewJB4Ae+us8LJEKy99gI9Zg1S90x3OWg0U9wxpw0WhoS3a4fqMWuwOj6zb3bYsOCA6zGAp6caMShWGiumydJuDPya48DRCqeiOQNxKam4/oGHMWz8ROWEUAllBXl45d67UHj8mDQXpJi9NK/kR2kupnEmVHKu6Lr81hNgBYAZf/03p8OBnYvnYfVn7ynq6k8M55CRokNGivD76X3DCTv2l7hezrY0y45L+uu7RMnf6Sw+ZGNS/gAwLEE9j2kJQwkjAEQHS/eFBxgJJvbSYWIvHWpaRPya68TqIzacbPa8JVCUfQIv3HkbUvoNwA0PPtolkwUdDgeWz/kG3775Gixm16dcngkCfLxEU/6yo56dpQtDKD6h5A8DgFKKg+tWYPnHb6C6uEARmfwMBKMSeUzurUNC6N837wuTdEwGQKOZYv0JOyand51ygBYrxYojbO7/nmGcqioAiupc970bBIJwP3mcjWF+HGYO4HB5fx2OVzqxMceOjdlOj5cWZh86gCdvvBoDRo7GDQ8+iuR+/T16f6XYs3E9/vficygvlG6fIsDOZgf/L8kuqHFWtBCACqCUktwGMQugvY9uWY9lH72O8pzjHpeDJwSD43iMTxMwKFY459S8Nhtw0zctsDFE5wJNBB9d7QtfdXi1ZeeLbVYsPsRmANw6yoDpfdVhLNW1UdzyjeuzIxJCebw9yySDRGemxUqxKceBdSfsyKv2fLIAIQQjJk7BdQ88hJjEJI/f3xMc2LYF3739Bk4c2Cf1pXN11Dbql7yTVVJfWOPvaB4AFUAIoXPm/Dh/z5Kfe+fs2e7x+4f4EExM12FSuq7D2do+emBwrIDt+a5bAI1mivl7bbhxROe3AIpqRSzLYsth4gnBmCT1xEqyT7K6/z17zvAzEEzto8PUPjoU1DqxLMuBTTl22Dw0voBSim2rlmPn2tWYNPsaXHf/g/APCvbMzWWkubEBm5cuxsq536Pg+FE5blEmOoXxvxSUaMrfQ2geAIWZ1Ds6RGfBMyDkn/DgcCCgPbY/sZce41IFppj8kQonnljEVuMrcMDrM01nDC90FigFHl9sxrEKNs0zIkHAo5PU05v+qx02LGRIALxlpAEz+inrxWi1AeuP2/HFdqvHkwZ9AwJwxR3/xKU33wZBpw5vTkdpqKnBoR1bsXn5UuzZuB4OO5snqwPUiyIduzy/NEuuG2j8Hc0DoBCDBw/WdW+ovplY6YsgCPPUfQWuPalsel890rq7F1vuHckjpRvPdDJ0iMBba614c6aPakrcpObnA3Zm5Q8AMweqS1kcr2TzZKR1Uz6HwVcPXJAg4PNtbnWkY6K1qQlfv/4y1s7/Ebf++ykMHXexx2XoCE31dSjNy0NZQR4Kjh/Dwe1bUZKbAyq7xUSrKOWmLs8v0ZS/h+mkW6+6yUyOyyQN1W+C0FRP3TPIh2Byug4T03UI6aCbvyNc2l+H11azKbmSehHf7LThtlGdLxRwtNKJH3axD2EaFCsgKUI93hGrgyKfIZ6u44GEMHW8jzLGCgbJ7l+Qj+dvvxkBwSHokRAPg9FHUXnMra0wt7XC0taK5oZGmFtblBAjn6OYtDivWGv1owCaAeBBpqfGJVCRfgAqTvVU8CXCn+CyAXpcnKaTpfRueLyAyEAOFY1syVZLs2yIDyUYn6au06471LVRvLXGwtQn4RSzVHb6P1QmMsXQe4bx0KlD/6O0QR1Dh5rq69BUX6e0GGrgMDg6eXF2aZnSgnRVNAPAA2RkQPAri/0ndYovAPDzxD0jAzhcOkCPi9POnc3vLhwH3DBMj1dXW5iv8ckmK7oHcKrpd+8OrVaK55aZUdPKrmz6Rbf3xlcT+4rZ3P+pKnD/n4K1jbGG9FBgkVXU3bg2N79RaVm6MpoBIDMzEmNHiaX0E4D2+fu/UkidhxkfyuOSfjqMTRY8Nj9+RE8BvaN4HClnc7E6RODllWY8k2lCikp63rNgcwIvrbSgqJZd0Qgc8I9RBgmlkoa9jAZAWnf1fJ+lmgGgBhwAeXFobvHzzwLaF6IwmgEgE5mxscFEj1dF0NtwVi0vnfLvFclj1kCdZO1WXeW2UXo8+LOZuUd7qw14eokFT041eqUnwGKneHmVBUfcSPoDgBn99IgJVs+pGQBK6kRUMXTZ4zigbw91fJeUAsUMhpleaJ9kyPL+Nf5GCaXc7GV5RduWKi2JBgAPl511FTITY2YTgS4DMAYyl1omhnO4d5wR112gR2Sgcooj2IdDfStFrhuNVxwisC3fidgQDj2C1KUEz0VdG8WTS8w4cdK9A02YH4eHJxgg8Oqqzl151I7DDN6d9O48pvRWRy5DaYOIhQddL2FL6cbjzZk+CDAC+bUiLLJVwf2B9H5BxREB8hm1kZnLCotzlBZG4w80D4CEXJbYLcJODB8BdKbcj3CoD8F1wwzISBFAVLJb3DRCj4NlTuaEQOCPk/Q1Q/W4YqBeNe/tbByvFPHGWgvTmN/TIQS4fbQeRp363vCmbDb3v1LeqDNxgrGJUVwwB4EDpvXVY0IvHZYeduCX/Ta0WOXzCKjvF+AO5ACl5J/L8oq2KS2Jxt/xnmOWyslMip1lJ/rD7cpffvrF8BiXqh7lDwBGHcEDFxnAuykUpcCcXTa8uNKM+jZ1ul4pBRYcsOGJRWa3lT8AZPbW4YJ49SjMU+RWiShjNOiGxKrHwXi8ku09JEX8sUUaBIKZA3T45BofzB6ih0mFxpqKqAOl95hyi4doyl+9qOcJ9VKmJHUP7xUS/BWAZwH4euq+lY0UU/voVVNidYpQPw4UYHIZ/5XyRooNJxwI91PXQJySOhGvrbVg7TEHpDBPEiM4PDzBBE6F+mThARtOVLmuPMN8Ca4fZlCNgfrtThuaLCyjmA0I+kvfDL1A0CeKx0VpOtgcQGGtCFGddqoSVAPkDYuou3plftHmo5DkEdGQCZWpD+8iMzn6cg7ccoBc4Ol7O8T2Gv+kcPV9hendeeRUi26FAk5hdQDb8h04XO5EXAiPEF/lNEqbDfh+lw3vbbTgZJM0+5qvgeC5aT4IMKpEU56Gk1J8uNEKM0PcOyNVhyFx6vBotFgpvt7helMmg0Bw8yg9uLNYMSYdwZA4ASMTdTjZTCX5vZ8LlecGlBJCnjJZ6PULC0vW5tfXe77loobLqE97eAGzoqNNPcMD3iQgbwHEY6f+v1JvppjUSx1JVqdDCDA0TsDuIgcazdIoyqpmijXH7ShrENHNn/OoIdBspViw344311lwqMwp2WlP4IBHJxqRrKKOf6ezPd+JdSfY4v+3jTIgzE8dXpusMid+zXH9faRG8JjQgecrwEgwNllAr0ge+TWiZL/5v6JC5W8hwC8A+XdFYMQ9Gw8f3360qYntB6OhCOow0b2IzMTYwWZCvweQorQseVUiCmpEJISpY6M9HR898OQUEx5e0CbZhkgpsDnXgc25DvSO5DG5tw5D43kYBem3RkqBEydFbMi2Y1OOA2a7tJs6IcDdGUZVJcr9lWVZbCnvkQEcUlRk1LBWZ6S42MSof4/2scdrjznx/W6rbIaAspBmQsVN4Mh8wpl/Xnyiprn974uVFUuDCfXuPirjWYDbkxz9ECj9DwDVNK9fnGXDfePUMzHudCL8CZ6aYsQzyyxolThr+kiFE0cqnDAIBEPieAyN49E7ike4G6dOi4PiaLkTWWUithfYUSmRm/9M3Di8vYJDrRTUOnG0ki2PY0yyupJTjzFWAKQzdGPkCcGkdAEjE3l8v8uGVcfszL0x1AFpBsTdhJL1IrgNrTFFuzZuhHbK7ySo6DFVL5N6xUXqHM5vQYksY7wIAcL8CKoZmo0IHPDxNT5uKT65ya1y4tllFllLp04R7schpRuHqEAO3QIIuvlz8NET+Ojbk7fsTsBiF2GxEzSYRZQ1UlQ0iCiuE5Ff44TDA5v1FQN1uG6Y+rr9nc4HG61Ye5zNA/D+VT6qaWbUZgNu+KrF5e+VEOCbm3zhb3Bvi8yvEfHRJityq+QbRCQYDNAZjGfdzKnoFM0tLWdquVsPghZQ2gKQFgI0AiijBCeoKJ7gBe7E4hMl5bIJrqE46j2CqISpyTFjeJs4lxISKcf1IwM5/N+FBtidwAsrzC6vd4jA0iw7bh6hXoWSFMHjPzOMeHqxBc0yGwHVLSKqJSjLkwNCgKsG6zF7iGocSGekoY1iUy6b8k+M4FSj/AFgf4mDyaiLDeHcVv4A0DOMw+uXmbAx24Evtlll+f07rFZEJaXippc/RHBk9JlecllysLBY8htreD3qeVLVB5mWHHsfT7GWEkiu/PU8MHuIHu9d6YP+0TwGxbC7r1cdcciuWN0lIZTHCzNMqvZUyInAAfdmGFWv/AHgl4M22BidvFPS1ZWUyjrDIF3CGQaEAONSBbx3lY9sYZ/iI4fw5g2X4Nj2X//6T2s05a9xNtSTqaMiJvWODkkPCJgH4F7I8Bn178HjqakmjOgpgP9NHxLSPkmOpZe8QwT0PFFN3/WzEeRDMDaZx/GTTtS0qNtgkRJffXu2/8hE9Tvc6tso3llvhZPh1BxgJLgnw/j7b1ppKAU+2Wxlat87c6D0MxlMOoLhCQJSIjgcr3Si1fXKxHNit5ixb9ViiCJF4sChIBxnFZ38JR+89lyNtHfS6CyoW2MowLSUHv05O7cBRPrafh89cMeFBtwy0gD/M9R9RwYRLD9sZyozy6sRMT5Np8pWsqdj1BFkpOhQ10qRX6NOV72UJIRxeG6a90w5/GGXjTn5b3pfHQaqqKohu8qJpQyVDDwh+L8xBuhlqC4B2sN+E9J1aLPBrdkZZ4RS5O3biaLD+xE/YMiLA+KD50t7A43OhHfsSh4iMzkuk1AsJQTdpL72gGgeT2ea0Dfq7BnSPnqCyiYRBQxTyxwiYHcCg1W0AZ8NjgAXxAuICeaQVeaETb78KEXJSBHw+CTT3zrJqZW6Nop3NliYTv88IXjgYgN89Op5r6uOOXCUwaPWqzuPKX3kDWUIHMHgWAEDogUcLndKniBbW1qMLT9+FZMcGrQmp65R8wBonBGVOOsUh2QmxT5KqLgYQICUF/bRA3eOMeKZzI7Fvy8bwD4AZ9VROyqavOdUPSpRwNtXmjAgunPZoSE+BI9NMuL+i4zQq98e+53vd7HH/of35FXT+OcUuwvZLMuBMZ77PaZ153D9MHnyQiiliYSKOzKT4zJluYGG16OuJ1YBZvXurZ+WFPstAX0FEn8e/aJ5vDPLF5PSO14XHRPMYTDjBuQQge92ShxYlJkwXw7PZJpw5xgjAk3qOT2ywBOCGf10+PBqHwxP8CLNj/ZSzXUn2GfdXtJfXcl/NS0iiurYDABPN2fKkbFEEEAAoeLC6cmxd8h5Ew3vpHMdvVxkelSUj52zLwBwuZTXFTjgysF63D3WCD+GUqJQPw7rGVuwltSLSA7nEBXkPbYdIUBSOIeJ6XoQSpFXLcLpZTmCvSN5PD7ZiHGpOuh47zJkKAVeXWNFLWNi5qBYAZcPUFd1w6pjdhwocV2xhvoS3Djcs0OMvtttR12rrD94DsC01JAAU3Zd01o5b6ThXXRZA+DS+Pgg0YjlACRt7hMdRPB0pg8uTGLvhhbhzyGr3MnUGAhoTyyamK5TTTZ2R9HzQP9oAWNT2hOkShvUP2Wtbw8e92QYcfVQvdfE+v/KhmwHlh9mP/0/cLEBob7q+rF9spmtFe/FaXoM9uAYY4ud4vOtNg+NzCOjU0ODQrPrGld65HYaqqdLGgCXJXaLcPD8WgCSZvpPShfw2CRpat1jgzmsPc7mBWi2Ugg80CfKO79eXwPBsAQBE3rpYBQIShtEWFXUfJQQYEgcj3vHmXDlYD26BahL+blCs5XilVUWplI5ABgcp77Tf161iJ/2soXCrh/m2e8zq7x93oQHGZYcEhh9bV3T0o3aqN4uj3cFKiUgMzY22E6wCqADpLqmn4Hg7gyDpHHf5AgeF8QL2FnApvl+3mfDyJ6CqrqyuUqwD8HVQ/WYOVCPrXkObMl34CBjZzcpiAnhMC5FwNhkHUIVHEssJf/dbEVDG7semD1YXbF/ANjAmMvgbyBIj/Ls83K43POWLQFu3Z0Y40BeyZ3QjIAuTZcyAKZHRflQA10MCsmUf0IYh0cmGhEpw6nhhuF67Cl0wkldf0ZtTuCtdRa8frkPBO+1AQAAeqG9k9q4VAEtVoodBQ7sKHDgWIX0zVROhycEyd0I+kUJGN5TQE8VTl10hx0F7ZMVWbkgXlDdKGOHCGzOY3tPF8QL4D08xWh3kTI1sITgjmmJ0daleaX3KSKAhiroMgbArOhok8XILQWlo6W6ZkaKgLvGyFfq1SOQQ0aKwJydXVAjYv4+m1e0n+0ofgaC8Wk6jE/TQRSBononjpQ7caxSREm9iMpGkamvACFAhB9Bj2Ae8SEcekdy6B3Fq76xEivNVopPNluZ1wsccNMI9f2u9hU7mMfwjvHwdMbqlvYhVIpByL3TkmLrl+YWP6ucEBpK0lUMAGI2kS9A6TgpLqYXgNtHGzA+TX7357XD9NheYEcb40l33l47hsTySFLZSU0KOK59xkBCKI9pfdv/jlKgtlVERSNFbasIq4OgxUZhs1M4nBQggI+Bg48OMArtUwK7B7RXTeg630d0Vj7+1T3X/2UD9IgKVJ9HhLV6JtiHoC/D+F932MN4+g/2IWgwUzA4Bs8AfWZ6cmzFkpziT6W4moZ30SUMgOmJMc9RitlSXe+y/nqPKH+gvanM1UMN+Hwr22nNSSleW2PBm1f4SDLdTO20j1bmEOYHdNEc1/OyJMuObfnsrv9QX4KZA9UX+2+2UuwpYntfFyYK4Dxsz7C6/8en6RAXwuH9jVZYHRJYAZS+Pz0xLmdJXtF69y+m4U2oz4SXmOnJ0TMpwZNSXnNTjgOiBz13mb11SHAj/lzVTPHueotEJwYNbyanyomvt7O7/gHgphEGVYZGVh9jTxAdk+zZs5DFQXG4jM1YGRwrYHSSgFculabiiAI6SsR5MxKjk9y+mIZX0akNgGkpPfpTSr4FIOluVdEkYkeh57J3OQ745xj3mpPsKXLi5wMeLTfSUBnNVorXVlvdqqLoHcVjtAqnGjpEYEUWW5wsNoTzeIjsYAnbDAx/A0FKRPu2nRDG4dXLTVIlp4Y4CVk0sV83XykupuEddFoDYHpUlA9E7gcAJjmuP3+fzaMn6qQIHhN7ubfxfr/bikOlnXTyjsY5cVKKt9ZaUN3Crv2NQnu5q4cT5TvE5hwHahi76U3o5flwxp5itudwSDz/p1BFiA/BS5eY0F+CeRoESNe3Gd52+0IaXkOnNQCoj/AugF5yXT+/RsR2xhp9Vm4eaUCkG4lXogi8stqMIoZpgxrezedbbdjP0Br3dK4frpel3FUKFh9i824JHDAmybMeDUqBvYy5CoNj/i6rUUfw5BQTRvaU4n3Qf0xLjLlKggtpeAHqfJrdZHpy9EyA3ib3fb7Z4Z471VWMAsF944xuJSu12YAXV5pR70YGuIZ38ctBm1utfoH2qXVTe6sv8Q8ADpY5UVDLZtwM7yl4fAjV0Qon6hieP4E7+6RCHQ88NN6IUVKEZwg+viQxKsb9C2monU5nAExJSgqASN73xL0qmyhWHvHs9L207hxm9HOv/rqqmeKFFWZY7JoR0NnZnu/ANzvc+42eMjzV6PoHgEUH2Y2bSQq4/zflssnbK5KH7zkqeTgOePBiSYyAYAfhPbKHaihLpzMAeFhfogSRnrrfT3vtsnajOxPXDNUjJsS9ry6vWsRra6ywaykBnZasMifelqD645ZRerdCT3JSUidifwmbOz02hPP4vAyHCGzLY4z/d2BMMccBD1xsdHukMQEuyUyKmeHWRTRUjzqfakYyE2MHA/g/T96zyULxy373yqpcRc8Dj00ywuRmKda+YgdeXmXRjIBOyPFKES+utMDmZprKhUkCJipwSu4oiw7ZmQ2caX11Hvdq7Ct2oNnKJvCQ+I4ZKwIHPDLBgIRQ94wbAryvVQV0bjqVAUCI+B4U6P6y+JDdrexqFnoEcrhrrMHt6+wrduCttRameQMa6uTESSeeW+Z+iEeq35hclDeK2Mg4Sc/PQDDWw7X/ALCJcfZCXCiHHi54YYw6giemGhDi3ojqWH2b4WF3LqChbjqNATA1MXoyQEayro8K4hDMmAxkcwI/7PZwHADtp7Opfdw/nW0vcOCddZ5NaNSQh+zflL/ZTeVv1BE8Ntl9L5Oc/LDbxvybnZQuwCB49r1ZHBR7CtncbWOSXX/Ow3w5PD7Z6FaLawJ6f2ZsbDD7FTTUTKcxAHhCnmVdq+OBh8cbcfUF7Ml1G7IdyCrzvC/9lpEGpHV3/2vcnOvAfyQ4NWoox6FSJ55dZmaeG3E6/3ehQdWjpItqRWxhnPqn44HMvp4fZLQ9zwkLQ+teQtpbFbOQFMHj+uHsXhwKBEKP+5kvoKFq1PuEu8D0xOgpFBjGuv6WkQYkhHEYn6pDLGNyHaXAJ5utTN293EHggIcmGN119QFoL6d6dpkZLYwxSg3l+DXHjueXS6P8Zw7QIcPDk/Fc5eud7I24xqfpJHleXIU5+78bjwh/dnmn99Hhgnj275MDvU/zAnROOoUBAELuZV3aO4rH5PR29xrHATe4YS2XNYhYsN/zoYAwXw5PTTVJ4q49XiniicVm1DJ2VdPwPEuy7HhnvTQhnJE9BVw3TL1xfwA4WunEvmK20z/HATP6eT6psbpFxEFGD6G7Y4oJAe4aY4Af4zCw37wAN7olhIYq8XoDYEpSj2gKTGBZq+OBO8f8ub55SCyPfm601Zy/z4aSes8H0xPCODw8wQBegrTmoloRD//chuyTWnmAmnGIwGdbbfh8q1WSttRp3Tncf7F66/1P8fV2diN7VE9BkZLGlUfsTAPEBA6SdPgL8iG4YTh72INAvAMSz1TRUB6vNwB4kFvBmPk/c6Ae0UF//03fPELPvAk6xPZZ60ok1Q+KFfB/Y6SJbda1UTyx2Mw8X11DXposFM8tM2Mp4wCcv9LNn+Dfk4zQq3yC8s4CB04wGqaEAFcM9Hzs3yECa4+zPUcDY3gEGKXRuxPSdEjtxvoFk7QZibHMSdYa6sTrDQCA3MCyKsBIcEn/M7sCE0J55qQboN1FufqYMopzQi8dZg2WZpOzO4H3Nljw1XatQkBNZFc58a95bZIlnQaaCJ7ONCHQpO7twCEC3+1iN3jGJOkQF+r597gt34FGM9uJgCX7/2wQAlw/jH1vEIkWBuhsqPuJPw8zUqNSAfRkWXv5AN05Y+bXDTNA74bn7ZudVtS0KqM1rx2qx8wB0m0cCw/a8dhCMyqaNCtASSgFVhyx44lFZubJd38lwEjw/DQTegSpfytYeNDOHF7jOODKIco0NFp1hC35z6QjGNrB5j8dpU+UOyFOOkVSYTQUR/1P/TlwOriJLOt89cDk89TPR/gTzBrEbi23WineWmNlivtJwXXDDJL0CDhFbpUTD85vw2bGRiYa7tFoFvHyKgs+3Sxd+2ZfA8EzmSZFTsWuUtVMMX8v++l/XLLOpUY6UlFSL+JoJdsXlpEiwChDr4IrBjDva9GZyXGyTVjV8Dzqf/LPAQdMYlk3JlnXoQfr8oE6t9ppHq10G0dEbQAAIABJREFU4mcFqgKAdnffP0YZJJ113mYD3lxrwQcbrWjVSgU9xr5iBx6YZ8auQumML1898FymEYnh3rEF/HeLhamGHmhvnX3VEM/H/gFg+WH2VsWnqpOkpm8Pntnjw4EyJVxrqBN1F/ueg8GDB+toY1UGy9qO9jbnCcFdY/V4dKGZ+SQ/d48d/aJ5N5Jv2DlV/kMArD7m3jjY01l73I59xQ7ccaEBwxK89id0XpqtFE0WimYz0GQR0WylsNgBiwNos4iwOACrAzDbKVqtFBYHhd0JiBQw2/6867fZ2v/+TOh5/CncxBECk77d5V/fRiUf3exrIHgu04ikCJVn/P3G1jwH9hSxuz2m99W5VUfPitlOsSmH7blL687J5pkhBLg4TWCaEkmpOAHAe9JLpaEEXrt792ip6CmCd3lQRYQ/QUJYxx+s5Ij2PgGs89SdlOLtdRa8dYUvfBQ4hBAC3DnGgAAjMH+/dEZAXRvFy6ssGJUo4LZRBgQr0FiFBUqBejNFdbOImhb62x8RdW0UjebfFL6FoskMBecjyHdffyPBnWP06KbS6X5/pc0GfLGNfdiWn4HgUgUy/wFg5VH2SaFT+8gr87AENgMAQF+pZdFQDq81AKgoJLNslANjXD/1XHeBAbsKHMyJV5VNFB/+asHDE4xM692FkPacgCAfgs+3sXdQOxNb8xzYW+TEpQN0uHygXhVlZC1WiopGEeWNIsobKCqbKKpaRNS2iKhrpV26oqHZQvHaaisAK/QCEOFHEOrLISKAQ2QgQVQgh6hADt0DOVV8l3N2Wd1qSjV7qB7+jA1w3MHuBJYcZDO4A4wEw2X2rPUI5BDhT1DV7OpnS2Iy4uONGwsLLbIIpuFRvNYAAKXJLMv69XD9LfvogdtGG/DKKvbf/NY8B4bGORRtsTqtrx4+eg4fbrRKerq1OCjm7rFhY7YdNw43YIQEjUvOB6VAVQtFYY0TxfXinxR+k0XLT+gINgdQ2kBR2uAE/lJSSAgQ7kcQGcAhKqj9T1wwh/gwTrK69PORW+XEiqPsXqvoICJbHP18rD9hRx1j6GZCmuAR46tvlIB1J1z+fDl/QUwEcEQGkTQ8jNcaAJQihaUvVTRj8svwBAHDEgTsLGBPxPpokwXRQT5IilDO/XpRqoBQP4I3VluY55KfjcomildXW9ArksfsIXr07yHNLma2U5Q3UBTXicirdqKkXkRBragpehmhtD3zvqrZ+bcWtn4GguhggqQwHjEhPGKDCRIjeEmVlsVB8c56i1tVNLeMNEBQ4FETRWAR4+mfEGC8hIm756JHMKMh13740gyAToDXGgAgJNzVEAAhcKsN6F1j9Mg+6WROyrI5gFdXW/DGTKOiTVf69+Dx2kwTXlppQUmd9P7wYxVOPLPEjNRuPK4YpMfQuI5rBlFsn6mQW92u7I+ddCK/RlSks6LGmWmxUhyvpDheKQJoV3Q8IYgKIkiP5JDWTUBSOIfoYI65o+bnW20obWD/0kclChgUq8z2tjXfgfJGtudqUKznWhWzlkVS0HCJRdFQCK81ACioyxWyPnriVnOfQBOHezIM+M8KC7NCqm5pr+d+YYaPIqeTU0QGcHj1Uh+8tc7sVob1uThx0okXV5iREsFjej8dRvQU/vaeG80URyucOHHSiRNVIvKrRVgZy700lMNJKUrqKUrqRaw62u4lCzQRJEdwSI7gkd69vRKmI8/fjgIH1rhRtWIQCG50Y6iXO1AK/OxGsu00CXt3nA/WxF1KiNfqDY0/47VfJEepQF08XvAShC4HxQrI7KN3qwf78UoRH/9qxT3jlJ265qMHnphswtw9Nvy0T9rkwNPJrnLizbVOhPgQXJwmID6UR361EwfKtNN9Z6bRTLGnyPm7gckTgvgwggE9ePSLEdCr+9/DBjWtIj7cyJ71DwCzhypT9gcAe0ucKKxlM6jjQ3kMcGMQmatwrB8RpV6rNzT+jNd+kSxWqFRTzm4crsfhcvYHHQDWnbAjKYLDlN7KJCmdghDg6qF69Ini8fY6C3PiUkeoa6OYt8+OU25jja6Fk1LkVVPkVYv4+YAdeh5I6dbemnZwjICEUA7vrre6lZsSH8pjel9lyv4AYJ4b3QpnDdJ5dBIjYbwZp3kAOg3eUQx8RqjLWqTZKk0JmI4HHrzYvVkBAPD5ViuOlKtj5G7fHjzenuWDIbEqqP3S6BLYnMDhcie+32XDgz+34dovW90acMQTgnsylEn8A9ybVBgZwGGEh5tq1TMOKKLU9b1XQ514rQFAQEpcXSOKcKum+HRiQjjcPMI9F75DBF5aaUaBG54EKQk0ETwxxYRbRrlv3Gi4R1eLilC0V3u4w6X9BcVaG4si8N1u9tP/zEE6cB4WvbqZ7TREQEolFkVDIbzWAKAMBgAASbPep/TW4YJ49zRlqw14dqmFOWtYaggBZvTV4d1ZPugdpXkDlMI7+ipKh7vvNzqI4KohyuXUrM+2M+8tob4EGSmeDwWyTlYE4YqllURDKbzWACBELGJZd6hU2ml294wzIDLAvY+x0Uzxn+UWNMgYf3eVyEAOL0w34b5xRkU6qWlodBSeENx3kVExr5XNCfy4h90rfkl/vSJhi4MljJ5Hzq4ZAJ0E73X0UprPcm7YXyqtu93fQPDEVBMeXdDK3PcbACoaRTyzzIwXZ5jgpxKFSwgwLlVAXCiH99ZbUVinjlCFGjH5+sFgMsJo8oGPvz+40/y5eqMRev0fp1PCcaB/6XBjbm2F0/mHcWq32WA1m9Ha3AyruQ02q3uZ8Z2ZYQk84tyY2ukuy7NsqG5hO037Gwgm9vL8NlzVTFHG4HUkQOOS7PIaGUTSUACvNQCMhqB9ZmtTGwAfV9aV1IvIrXJKOgktOojgwfFGvLDSvc5lRbUinl9uwfPTjbLMAXcFJ6XYXejEuuN27C9xdon++XqDAUFhYQgKDUdASAj8g4IQEByCgOAQBIWGIiA4BH6BgTD6+MI3IAAGk6ld4fv5yS4bFUW0NjfD3NoCq8UCS1sbWpua0FRfd9qfejTV16OxrgaNdXVoqqtDY23tnwyLzsi2fAcOlbXiwiQBF6cKHp1y2Gpzs+6/nw5Gneef9Q3ZbDJTQrZKLIqGgqjjqMlIZlLMagK4PJ96fJoOd2dIHy+ct9eGOW4kAp1iSByPxyaZFHELNpopVh+zY9URO/PwIzVCOA7hkVGI6BGN8KgohHWPbP8TGYWwyEiEduuOwJBQpcWUHNHpRH1NNarKylB7shK1lRWoLi9DTWUFaiorUVlchMa6WqXFlJSUCB5T+wgYlaiDTmZbYM4uG+btY3vmA00En1zjA5OHDQBRBG7/vg01DF4LQvHwkrySN2QQS0MBvNYD8BsbwWAAbMq1Y/ZQHcJ8pdWwVwzSo7hexOZc905ce4qceHmVBY9O8FxcM7dKxLIjNmzJdcDupZ5+QgjCo6IQFZeAyLh4RMbFIyo+AVHxCegeEwudXrn6cKXgeB6h3bojtFv3s76mtbkZFUWFKC8sQEVx+3/LCwtRVpCP5oZ6D0orDdlVTmSvd+KrHTZMTNNhUm8dQn2lV7LVLSIWH2I//V85WO9x5Q8Am/PsTMofAESQDRKLo6EgXu0BmJocPYyjZAfL2owUAfdfJP14XpsD+PfiNuRVue8z7xPF48kpRlldhPuKHZi/z46jld6l9f2DgpGQ1gtxKamIS0lFfGoaYpNTYPKV3x3flaivrkZR9nEUnjiOouwTKDxxDMW5ObBZvGcarMABY5IFXD7QgOgg6Z6lF1eYsZuxjXaEP8GHs31l91D8FZsD+OfcNtachVpTbkm3eYB3bRYaZ8WrDQAAZFpi7DEQmuryQgK8fplJlnhhVTPFwwva0MjYaON00rvzeCrTKOlJgdL2fuvz9tmQX6OG4D7FuX6KgaGhSOnbH8n9+iOl3wAk9EpHSEQ3z4mn8SdEpxMVxUXIO3IY2YcOICfrIPKOHIbVbFZatHNCCDAiQcCsQXokhLnn/dtV6MBLK9mNoH+NN2JMkucdsO6EKQkh7y/JKb5XYpE0FMTbDQBMT4x5iBK8zrI2JpjDGzNNMMiQcFdY68QTiy1olWDkbmI4h2enmdwux6MU2JLnwI97rG5NWpMTnV6P5H79kTpgEFL6DUBKv/6I6BGttFhdhuP792LDol+QfegAWhoa4BcUhJR+AzDuksuQNnDwWdc5nQ4U52Qj59BBZB86iGP79qAkNwdUpYMeBsUKuO4CPXoyGAI2B3DvT62obGJ7b3GhHN65wsejbX+B9j3p4QVm5hCfKNJ+y/NLs6SVSkNJvN8ASIkKoyJfCoApq29Kbx3uuFCeBiJZZU78Z7kZNgkcZgmhPJ6dZkSgie0rO14p4qsdlt9GuKoHQRAQn9YLA0aORv9RFyJ90BDojdKHZjTOTVtLC97790PYunL5WV8zavJU3PvyGx2uemhraUH2oQM4uHUzDmzbgryjR/5W/qgkhAAjewq4bpjepV4eP+y24Uc3ev4/PdXo8VHFdifw0II2FNUyf/47luaWjJBSJg3l8XoDAACmJcXMBXAVy1pCgPvGGWTrxLW9wIHX17hXHniK6CCCJ6f6oHtAx7+24joRX++0YW+ROkrBOI5DUu++GJxxEQaMHI2U/gMg6JQdiNTVMbe24LGrZyH/2JHzvjYhLR2vzp3PlGvR0tiII3t2Yf+WTdi3aSMqipl6eUmOjgem9tHhikH683rZKppE3PdjG7NRn96dx0uXmtgWM0Ip8N5GCzacYN8DKHDrstySLyQUS0MFdAoDYHpKfBoVnVlgrGoQuP9v7z4Do6j2NoA/Z3dTNgmkEAgQQg0EpNfQexEIVUER5KJeEJEiYr9exYKocC3IVRBFQMCCSknoCERCAKVDJAkhhBRIJ73u7rwfeFGvkLA7O7uzSZ7fRzNn5nF1d86cOed/gNdG6dHBRltxHooxYMXhEkW2va3lIvDS/a5o26DyrKUGCVvPluOH02Wqr+H39KmD9sE90bF3P/QYMhQ+deupG4j+xwfPP4ND234y+/hB4yfi2WUfWX3d1KREnD0agXORR3D6SDiKCgqsPqc1PFwEHg12wfA2ugqH59/cVYLTifJupEIA743Xo5WffWf+bfqtzKpdCgHE611qt9kSFWX9GmdyKNWiAwAAowMDvhDAE3Lbe7gILB2nR4CPbRbf/3i2HF8fV6aam5MWeHpAxaMWv10z4vMjpbKrkymhUfMW6D1iJHoNH4kWbdvJ3nqUbOtabAzmhQy36F29EAKfhO1Dk1YWz72tUHlZGc5FRiBy3x6cOLAPeTezFTu3pdo11OKpAS7w9/zf34KjV26N5sk1OEiH+YPs+3pr7+8GfPaLdSs2JIjJO+MStygUiRxItdntJci39ilIYjYAWePJZcZbFcU6NtLB2035m9V99bUoLQeiZW4X+lcmCTiRYES5QUIH/z+fVvJLJXx8sBSbfytDUZn9J1+1aNsOIdP+gdmvv4VHFjyLjr36wKeeH2/+Dixswzpc/O2Exe1qeXmjQ6/eiuXQarVo2LQZgocMw4THZ6J9cC+4eXggOz3N7iMD6fkS9l8qhwDQpr4WQgB5JRLe3l2CUpmj6G7OwEv36+267n//pXKsiii1auRRACfC4pIWKZeKHEm16QDEZuXlt/L21EOgv9xzlBqAiLhytGmgRV0P5UcCOjbSIq9EQlyGMk/ml1JNSM2T0K2JDtGpRiwOK0aMAvUHLFE/oDFCpj+GeUvew6TZc9G2e3C1rKhXkbLSUkDgf2r/VyVb136O6wlXLW7n5u6OAWPH2yDRraqNfo0C0G3AIIyb8QQ69OoNjVaLtKRrKC+zzyi0SQIuXDfi4g0jOjbSYk1EmVXf28d6uaCDv/1+br8/XYavjpVZ+9pRMglMvZyd5xiTNUhx1erRbGRgoIsOpb9JQHtrzuOsA57s54IhQcpPTpMkYN3xUmw/J7+C2N/V9RDIKpIUmWhoDg9PT/QdGYJB4yaiTdduNe4J//KF8wjdsBZnIn5BTmYmhEaD+o0C0GPIMIx/fCZ86zdQO6LZXnh4Ii6dOmlxuzZduuL977baIFHFykpLceLAPhza/hPOHAmHwWCfia16J6DYiq9rc18Nlk90gz36iAYT8OXRUuyOUuT3ZWVYXNI8JU5Ejqna/XKPCWzcVoJ0EoDVL9sGttLhqf4uNqkToMDEHLsLbNceIx6aikHjJsBFb9+ZzI7AaDRg7dK3EbrhqwrfmTu7umL2629h2IOyFqXY3TtPz8KxfXssbtdz2Aj869M1NkhknpsZGfh56w/YvXkD0lNSVMtxL0IA747XI8gOE//S8iV8+HOxUkt9L+lLpK5bkpMdu7oTWaXavAK4LTY7N6Olt2eJEBhu7bkSskw4cdWIpr4axV8JdPDXQqu5VSvAkbno9Rg8/gHMW/I+Hpm/EIHt2tfYZXsrXn4Oe77dVOkxRoMBJ37eD5969RDYroOdksmXmXoDZyJ+sbjdiIceqbQwkK3p3d1xX9fuCHl0Bpq3aYv83BykJSeplqciw9o4YWRb239fDkSX4509JbKLE/2VAMolSYzedi0pUYFo5MCq3QgAACwGNCcDA3YD1ncCgFu9+CFBTpje0xm1XZX9yHZcKMdXkdZN1LGF2t4+GDN9BkZP+wdqeXmrHUd14aHbsPxZ86ug6nQ6rNx1AP7NmtswlfWy0lIxa0i/W3MZzOTs4oLPfz5S6QZDakiKu4wf16xCeOg2GMqVe8UmVy0XgZUPu8ku3mWOuHQj1kaWKbuXh5BeDLuc/L5yJyRHVe1GAADgMCA19vIN1QlTCABFFp3HZ5qwJ8qA4nIJTetoFdugJ8hPC283gVOJjjESUM+/EaY+swjPLvsInfr0g4trzRvqv5ulc59Efk6O2cebTCYUFxag57ARNkxlPTcPDxgNRlz81fw9tSbPmY/gIRZvwmlznj510HPYCAydOAnArSWO8jsCle9PYY4n+riibUPb/MSm5klYE1GGLyJLkVGg6NPD5rC45OeUPCE5rmo5AnDbmOYNG0sa7TEADZU8r6tOYHBrHYa2dpJVS/xufokz4JNDJaptxetbvwEemb8Qgyc+CK22qu8SrayEmGjMC7F8MMm9dm1s/vUcNFrH7mdLJhPeXzgXEbvC7nls35Gj8cJH/4WoAqse8nNu4ofVnyFs4zq7717Y0V+LxSF6Rev9S9Kt3Tt3R5XjVJLRBqOGUmSBQTfkcEJC1dnqkaxSrTsAADAmsEkXCaZwADbZJ7ZJHQ0GtNShc4AWTX20Vn3hL90wYuneEuSV2O99QC0vb0x6cg5GPzoDzi622ROhqovYFYb3FsyR1farIyeqxKoAyWTCj1+sxveffoLiwjvX3evdPTB5zjw88M8nq8TN/6+y0lLxzScf4cAP38NotP3KAWct8FqIHu3uUa3THAYT8Pt1I04nGXAs3oC0fNv8NgjgQpmLNHBvVLJ6FZjI7qp9BwAAQpo3HgKNtB2Auy2v46kXaNdQi2a+WjT2Fmjso4WPm4BzBQ/U+aUSMgtMSMuTcCXThJg0I2LTjCixw+tLrVaHkOkzMGXeQrjXqmX7C1ZhP//0Az568VlZbVftOwT/Zi0UTmQ7+bk5OL5/Ly6fP4f8nJvw8PRCq46d0HPYCNTy9FI7nlVSrl7B6jdflzXpUY6Gnhq08tMisK5Aszpa1K2lQR0PQFvBU0KZEbiRY0LiTRMSs01IyDLi4nUTistt/kAQV+6k6b/30rUbtr4QOZYa0QEAgJBA/16AZicAu89oc9bdmhDk9P8PBAWlgMEIlBjUmfnXpktXPPXGEjRrfZ8q169qzh49gn/PmGpxOyEEvjsTJWvjHLKdiF1hWLPkDWSnp9n92loh4OYMuLsATloBgxEoLJNQVCapsmeHBPyu1WLYjpik6/a/OqmtxnQAACCklX9HmDR7AfipnUUNrm7ueOLlVzHioUdqXPEea5QWF2NqcCeUFlu2JDqoUxcs37LNRqnIGkUFBVi/bCl2f7PRon0QqhMJOGlC+ajdcakZamchdTj27CSFxWblp7Xyqr0dQowAUHPq1eJWnf631m1Cl34DePO3kM7JCRnXUxB38YJF7R5d+Dyat+EoiyNycnZG90FD0Py+djh7NAKlJTWr3o0EbC93Kxu791Ka+UtbqNqpWrN5FBAWn3zZCJfuAqgRu1sJjQYTnpiF5Vu2O/yadEc2dcFz8Kln/sBRu+7BGDx+og0TkRKChwzDJ2F70al3X7Wj2IsEYGn3uKSJ+86nFaodhtRVo0YAbovLzi6Nzc7b0qqOVw6Awaimn4Nv/QZ4ZeXnGDllmsMvRXN0rm5u6NCzN44f2IuSoqJKj23Rth3+vXotXN1sOueUFKJ397hV3tpNj4snjsNkr0017C8LJmlS2JXkVYdvdQSohqvRd4XY7NwTgXVq7xcQvaBQwSBH0XdUCF5fsx6NW7Y0u01JcRHOH49E1MlfkRwfB5PJBG/fujZMabniwgKcPx6J30/+iuT4K5AkCV6+vna5tk+9eugfMhY3M9KRGHcZf1+I7aLXY8ITs7DwvQ/gXru2XTKRMoQQuK9rd3QdMAgXThyzqOhTVSAkaadGJ0aFxiWfVjsLOQ6+DAbQtWtXpwa5Gc8B0qsA3NTOYw2fuvXw2Ev/wsCxE8xuk5OZiU0fL8fBrT/eURK2fkBjPDz3GQye8ICqcwey09Pw9QfLEB667Y4tYRs2bYapC55F/5Bx9suTkY5zRyOQlpIEJ2dnNGzSDJ379uNTfzVQWlyM71etxNYvVttt+2EbSpUk8dLOK4nr1Q5CjocdgL8YE9SkGQzGTyQhRqudxVIuej3GPzYTDz75lEU3ofhLUXhz5mPISkut9Lj+IeOwcNmH0OnsXyUw9vxZvPXk48jJzKz0uKEPTMa8Je/xdQcpIuVqPFa/+Zrd6gYorAgSPtC7lry3JSrjzspORKjhrwD+LjYrNyf2Zt7mlt7e+zVC8gcQqHame9FotRg4dgL+9eka9Bw2AjonZ7PbZqen4eVHJpm1HvpabAzysrPQfdAQa+JaLD0lGa9Mewi5WVn3PDb+UhRKiorQpd8AOySj6q62tzcGjZ+INl26IjU5EZk3qsRSeROAr40wTdh1JXn77xlFVX4Ig2yHIwCVCGnVqAdM4lUAo+FgKybca9XCsEkPI+TRGfBrFCDrHP9ZtACHd2y1qM373/6ENl27ybqeHJbuVy+EwAc/hSGwXXsbpqKa6PyxSHz32QqcPxapdpS7KQXE11rgw+1xib+rHYaqBnYAzDC+ddOmRoNhOiCmS4CqdV2bBrXG8MlTMPSBSVZVmMvNzsL03t1gMlq2+1C/0WPwwkf/lX1dS2TeuI7HB/SyuFDL0AcmY8G7y22Uimq65Pgr2Pf9Nzi49UfkZt97ZMrGLgkJa3Uo27D1Slq62mGoamEHwDJidKuAvjDhYY3AQ5Jkn2JCge3ao/eIUeg9YqRia/l/CduBZQvnWtzOw9MT35y0rCCOXPt/+A4rXn7e4nZ1/OpjXcSvNkhE9CdDeTlOhR/CiYMHcPLwz7iZYaeCehISIbDJZMJPu+KTTtrnolQdcd9Xy0g7Y5OOADgyJrBRGiDeUPoCOp0Oze9rh6BOnRHUqTPu69oddRv6K30ZZNxIkdWuIDcXRQUFcPOwfX37jOvy3rlmZ6TDYDCoMmHRkVyLjcHZyAhkpCTDRa9HgyZN0X3gYHjWsc+ySUeTnZGOU4cP4vq1BJSXlcGvUQA69emHgBbypvronJwQPHQ4gocOh2Qy4fLF8zh//BgunzuL2AvnbDZnQIJmys64aw75HoKqlpr9C6mC1p27wFXvBo1WCw9PL9Tx80Pdhv6o598I9fz94d+shV225bVksuBfCSGgc3JSOM3dyb2OVqOBtoptWaukxMuxWP3mazh//M57hE6nw/1TpmH6ohdqzCZFhXl5WLfsHezfcvftgLv0G4BZ/37DqtE1odGgVYdOaNWh0x//7GZGBpLj45CekoK05CSkpyShIC8PpUVFKC4qQnZaKjIq6SRI4BAt2RY7AHY2f+ly2U8cSmrYtJmsdr4NGtqlgwLIz1i/cZMqt2e9Us5FHsWSOTNRXHj3lV8GgwFhX6/DxV+P4611m+1WREktWWmpeHX6FCTHX6nwmNNHwrHowbF4ddWXaNc9WLFre9etC++6FRfSCt3wFT5/6/UK/86bP9lazfyVJHQI7iXrCbDn0OE2SHN3nfv2l9XZsGdGR3LjWgKWzp1V4c3/rxJiovHO3FmQqm/ZWxgMBrz91D8rvfnfVpiXh3fmzELGdXmvxoiqInYAaigXvR7jHvunRW2cXVww/vFZNkp0J/datTD60RkWtXHVu2HMjCdsE8jBrVv2Lgrz880+/tKpkzi03bJloFXJ/i3fIu7CebOPz8+5ia8/XGbDRESOhR0AmUxCVPnNNCbNfhpBnbqYffzMVxejnr/yExIrM23BIgS272D28bNeewM+davVtg5myc3KxPEDey1ut+e7TTZI4xj2fGP5v9uRsB0ozMuzQRrlCGGo8r895BjYAZBJY4KsDcTLSkqUjiKbs4sLXv9iHTr27lPpcTqdDk8tfhv3PzzVTsn+5OzqisVr1qFttx6VHufk7Iz5S5dh2IMP2SmZY4k69ZvFNR0AIPrM6epQ7/4Ohfn5uBpteT0cg8GA6LP22S+nVO5vgQaVb0dJZCZOApRJ0qBAzoaa5ryftadanl5466tNCA/bjl2bNiD67Jk/3gt7eHoieMgwTJo9V7H6A3J41vHFOxu/w6HtP2H35o2IvXDuj4y1vLzRc9gITH5qLuoHNFYto9pyZK5Bl0wm5GRm2GSpKQCYjEacDD+EU+GHkH49BQJAvUYB6D5wMLr0G2CzyZo5mekWF5C6zZzS2EqQ+1sgQWv+ex6iSrADIJck5cuZp1t8j73k1SA0GgwcOwEDx06IYwCwAAAPD0lEQVRAaXExMlNvwNXNDd6+dR1mYx2NVoshEydhyMRJKCkuQlZqKvTu7vCq4+swGdVkzS6Ebh61FEzyp5hzZ7Di5eeReDn2jr/t3LgezVrfhwXvLkeLtu0Uv7Y1Sxxt9Xn8XXGBvA6AyVTGDgApgq8AZJIgZH0JC3Ide59xF70e/s2ao45ffYe9sbrq3eDfrDl86vk5bEZ7a9IqSFY73/oN4F67tsJpgFPhh/DK1Ml3vfnfdjX6d7w45QGb1Nb39q2L2t4+strK/SwtVZgvb65BscGVHQBSBDsAckkmWV/C1MRrSichQvP72qJB4yYWt+tz/yjFs6SnpOD9Z55GWWnpPY8tLS7Gu/NmIztD2TL2QqNB7xH3W9yuaVBrNGpun+0+blxLsLiNAMoPJyQ4zkQiqtLYAZBJSCJZTrvk+HiloxBBCIFpC5+zqI3e3QMPzJqjeJbNK/6DIguGt/Nzc/Ddyo8VzzFp9jw4u7pa1GbaM5Z9htaQ81sgAbJ+d4juhh0AmfTxyfEA7v2I8zcpV+9dlIRIjv4h4zB88hSzjhUaDRa+/0GllerkKCspwdHduyxuFx66DYbyckWz1PP3x4KlyyCEeXN1xkx/DMF2KiKVdzMb+Tk35TSNVjoL1VzsAMi0BTBKgMV386QrcdVy2RU5hrlvLcWk2U9XOjeilpc3/r16LXoNt3yI/F4SYqNRUmz5RNfC/HykXFV+dKx/yDi8tHJVpfMcdDodHpm/EDNfXaz49SsSf8nyJYoAAEmqeFIFkYW4CsAKQiAGEu6zpE1ZSQlizp5Gux49bRWLVHQtNgb7f/gOF04cQ3Z6Gtxr1UZAYEv0uX8U+o8ea/NJi0KjwfRFL2LQuIkI27ge5yIjkHE9BU7OzvBv1gI9h43AqEcetcnEPwDIvynrqRYAkJudpWCSP/UePhLtg3th58b1OPHzfqTEx8NoKEc9/0bo3Lc/Rk/7h92XuZ4/dlReQ43gCAAphh0Aa0jyhuPOHYtkB6CaMRoNWLv0bYRtXP8/BXlyMjORcjUex/fvxQ+rP8WLKz6zy2ZQAYEt8dTit21+nb/z8PKS3VburH1z1PL0wsNPL8DDTy+w2TUsIXflgzBpOAJAiuErACsICb/KaXfuWITSUUhFksmE9+c/jR3r11Zaje9abAyenzQO12Jj7JjOvpq0CpK1gZOrm7uqxabsqTAvD3EXL8hpaiiWtKeUzkM1FzsAVtAatYcBWFx/NfrMaWRWsg84VS3b132JyH27zTq2MD8fS+c+qfiEN0fhqndDz2EjLG7Xb1QInJydbZDI8UTu3QWj0WBxOwGcOhAfn2uDSFRDsQNghW0JCTkAzlnaTjKZqvUubDVJSXERvvt0hUVtUq7G48CPW2yUSH1TFyyCi15v9vF6dw88PPcZGyZyLAe3/SSrnQQcVDgK1XDsAFhJEvK+lIe2/ah0FFLB2YgjKMi1/KHsyK4dNkjjGBo2bYZn3vsAWu29pxjpdDos+s/Hdt9lUi3pKSmIOinrzSEkjWAHgBTFDoCVNCZJ1pcy6UocLpw4pnQch1RWWoq8m9myN2dxZHKXc129dEnhJI6l78jRWLx2Q6U39gaNm+CtDd8geMgwOyZT155vN/6xkZWFSjQFBuVrJlONxlUAVnJ19fy5uDQvE4CvpW2//2wl2gf3skEq9eVmZWLrl2twdM9OpCYlAgB0Tk5o16MnRk6Zil7DR5pdoMWRFRXIK8telJ8PSZKqxWdQkU69+2LVvnBE7ArDyfBDSE9JhhCAX6PG6D5oMHqPGAWdk5PaMe2mMD8fuzZ/LbO12Bl6/brj7SRGVRo7AFbaEhVVNjow4HsBWFxT9ezRI7h0+hTadOlqi2iq+fXgAfxn0fw7ysEaystx9ugRnD16BJ379scLH/0XHp6eKqVUhpevvEp6Xr6+1frmf5uTszMGjZ+IQeMnqh1FdaHrv0RhnrwNgAQkuT0HogrxFYACNDDJ/nJ+u/IjJaOo7vSRcCyZM/OeteDPRPyCV/8xBaXFxXZKZhttu/WQ1657sMJJyJHl5+Zgx7q1cptnurrUNm+ZCZEF2AFQQGhcynFAklUU6PSRcBzbt0fpSKoozMvD8mfnV7oW/q+uRF3EN59U7Q5Q606dERDY0uJ2wx6cbIM05Kg2LH8X+fK3Av92S1QU64eT4tgBUIgEzTq5bdcseUNW/XRHs3Pjeos3OAndsFb2sKgjEBoNZr26GEJj/lep57AR6NSnnw1TkSOJOXcGe7//VnZ7Ac1XCsYh+gM7AAopNelWAZDVxc+4noKNHy5XOJH9Hdtv+UhGWWkpTv1yWPkwdtSpTz/M/NfrZnUCWnboiIXvf2iHVOQIysvK8Om/X5E78x8A9oXGXTutZCai29gBUMiB+PhcSFgpt/2OdV/ixIF9SkayOzn7m99qV/W3SB4z/TG8tnotGjRpete/65ycMG7GE3h30xa4eXjYNxypZu27byP+UpTs9pIG9t/QgWoMrgJQkJOT6aNyg+YZABb/wkuShI9eWoSPt+9GPf9GNkhnW5IkwVBWKqttWUmJwmnU0W3gYHTq2x8Xjkfi/PFIZKWlwqO2JwICWyJ46HD41K2ndkSyo6N7diHs63XWnCJ8Z2zSEYXiEN2BHQAFbY1OyRoTGLBaAhbJaV+Qm4v35s/Bko3fwlXvpnQ8mxJCwMfPD+kpKRa39W3QwAaJ1KHT6dC5b3907ttf7SikomuxMfjkleetOodGiCUKxSG6K74CUJipTCwBpHS57WPPn8WS2f+skpvFdOwtb2Jb576cEEfVR2bqDbwxcwYK8+UVifp/e3dcTtyvVCaiu2EHQGE7ExNvQoiXrDnH2cgIrHjl+SpXOnfM9BkWzYYHgPbBveDfrIWNEhHZV37OTbw2Yyoyrls+EvYXJUbgaaUyEVVEq3aA6ig2O+9cKx/PgQCayj1HQvQl3Lh2DT2GDIPGwpuqWrx96yI/5yZiz50163hXN3f869PP4Vmnjo2TEdledkY6XpsxDdcux1h1HgHprZ1xydsUikVUIXYAbKSlt+dJjcBMWPEZJ8REI/rMSfQafn+V2Su9U99+SLkaj8TLsZUep3f3wMsrV6F15+pVBplqpqQrcXhl6mSkXJW3EuY2AVzJN+imJuTkGBSKRlQhdgBs5PLNvPQgn9oCEIOsOU9aUhLOHD2CLn37w712baXi2YxGo0HvEaNQx68+4i5eQHFh4f/8XQiBHoOH4uWVqxDUsbNKKYmUc/pION6c+RhuZsie+nObQZjEhH1Xr1nXiyAyU/XfjURFiwHNb4EBewRg9X6nbh4emPfOMvQdOVqBZPZhMhoRfeY0EmKjUVpUBB8/P7Tr0RN1/OqrHY3IaiajEd/+dwW+/e/H1hT6+YOAeDk0LvFdBaIRmYUdABsb1bRpfY3OeAaA1Xc9IQRGT/sHHn32BRaTIVJRytV4fPLKC4g6+asi5xPAnq5xSaMXA9b3JIjMxA6AHYxp0WSwJEz7oNArF596fvjnK6+h3+gxSpyOiMxUVlKC7z9biZ++WIXyMsX250kxorzz7rjUDKVOSGQOzgGwg9ibuVeDfDwzASgyfl9cWIije3Yh6rcT8AsIqJKVA4mqEoPBgINbf8B7C+bgxM/7zd7x0gx5GmhG7IxLqfr1sKnK4QiAHY0ObPyGgPSa0udt260HJs+Zh859+0MI/iclUkpZSQkO/LQFP37+GdJTkpU+famQNKNCr1w7qPSJiczBu4WdjWnZeIUkSfNscW7fBg0xcMw4DH3wIfg3a26LSxDVCHEXL+Dg1h9weMc2i7e4NpNJQEwJjUv83hYnJzIHOwB2NgnQFgcGbALwkC2v07xNW3To1RsdevVBu+49oHfnpEGiimSlpeL8sUicOxaBc5FHkZl6w5aXM0Hg6bDLSatseRGie2EHQAWTAG1xi4CVEJhtj+tptTr4BQTAv1lzNGoRiPqNAuDh6QW9uztc3dzYOaBqT5IkFObnobigACVFRci7mY2Uq/FIuRqP5PgryE5Ps1eUMiGkx0IvJ2+21wWJKsIOgIpGBzZ+UUDiul+imqFQSNKk0CvJu9UOQgRwFYCqLmfnHg3y8cwAcD+4MRNRNSalC5MYERqfHK52EqLbeNNRWWhc0qcC0hAA19XOQkQ28atOpwsOjU/6Te0gRH/FDoADCI1LDjeivBMADg0SVR8SJGnFDc96fbdFJySoHYbo7zgHwIEsBjSnWgS8DIHXJcBJ7TxEJFuaSZJm7LqSvEftIEQVYQfAAY1q7t9Ko9F8AmC42lmIyCImQNrkpJMWbo1OyVI7DFFl2AFwYCGBjccA0qcAWOuXyPGdNglpzq7LySfUDkJkDq4CcGCx2bmxjb1812o1JqMG6AjAVe1MRHSHy0LguW5xSXPXZOcpXi+YyFY4AlBFjA3yrWUyuT0OSXoJCmwtTERWi4Ik3i8ISNx8+DAMaochshQ7AFXMpLZ1PYrL9E8A0uOQ0EHtPEQ1jBHAPiHh865XknYsBkxqByKSix2AKmxMYOO2EjAJMM0ARBO18xBVVxLwOyA2SAbN+l0JCalq5yFSAjsA1cAkQFvYMqCPRhKDIUmDIRAMwFntXERV2E0A4ZIkHdRodftDYxOi1Q5EpDR2AKqhMQ0busFN29cEdBOQWgMiSABBEuCpdjYiB3RdQMRIkhQDjYg2GaWj7vFJZ7bcGu4nqrbYAahBxjZr5mfUGBsBxtpCaD2EkDxMJlFLaExekqTh/wtUbWkglUmSVCAJTY5GMhWYtKJAwJSnEaXxO2Iy89XOR0RERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERE5GD+D5B5reqpsdrfAAAAAElFTkSuQmCC	-18.00	10	e3204bd8-ac3d-413f-bd7b-2727e9c7f598	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	2025-10-04 00:01:17.932188+02	2025-10-04 00:01:56.330214+02	5	2
\.


--
-- TOC entry 3888 (class 0 OID 16529)
-- Dependencies: 223
-- Data for Name: moveout_lists; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.moveout_lists (id, created_by, items, status, created_at, updated_at, title, description, generated_by, branch_id) FROM stdin;
74e62515-78ae-4c10-99f3-072d2f4181fc	\N	[{"itemId": "9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0", "itemName": "Surami", "completed": true, "completedAt": "2025-10-03T22:51:31.948Z", "completedBy": "3edce773-cadd-43f2-ad49-5dc72a2c80a4", "completedByName": "Kaumadi Mihirika", "currentQuantity": 9, "requestingQuantity": 3}]	completed	2025-10-04 00:51:20.550136+02	2025-10-04 00:51:31.949334+02	Moveout List - 10/4/2025	Generated by S Laksh	572c001e-2c97-40c1-8276-c73a0bb6572f	bb6313ee-0513-4805-81c2-3072e9618640
12cb0f78-8095-497b-afae-b738027755a6	\N	[{"itemId": "9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0", "itemName": "Surami", "completed": true, "completedAt": "2025-10-03T22:35:57.224Z", "completedBy": "3edce773-cadd-43f2-ad49-5dc72a2c80a4", "completedByName": "Kaumadi Mihirika", "currentQuantity": 1, "requestingQuantity": 1}]	completed	2025-10-04 00:27:48.305788+02	2025-10-04 00:35:57.225481+02	Moveout List - 10/4/2025	Generated by Kaumadi Mihirika	3edce773-cadd-43f2-ad49-5dc72a2c80a4	e3204bd8-ac3d-413f-bd7b-2727e9c7f598
13e36a95-85d2-4ac7-b5b0-7101df781095	\N	[{"itemId": "9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0", "itemName": "Surami", "completed": true, "completedAt": "2025-10-03T22:42:42.605Z", "completedBy": "572c001e-2c97-40c1-8276-c73a0bb6572f", "completedByName": "S Laksh", "currentQuantity": 1, "requestingQuantity": 1}]	completed	2025-10-04 00:35:42.359024+02	2025-10-04 00:42:42.605925+02	Moveout List - 10/4/2025	Generated by Kaumadi Mihirika	3edce773-cadd-43f2-ad49-5dc72a2c80a4	e3204bd8-ac3d-413f-bd7b-2727e9c7f598
\.


--
-- TOC entry 3889 (class 0 OID 16547)
-- Dependencies: 224
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.notifications (id, user_id, title, message, type, data, is_read, created_at) FROM stdin;
fe889d4c-2b39-4ce9-a692-abd833feb624	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	Stock Alert: Surami	📉 STOCK ALERT - THRESHOLD LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 9\n🎯 Threshold: 10\n📱 Alert Type: THRESHOLD\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:02:58 AM	stock_alert	{"source": "stock_out", "item_name": "Surami", "threshold": 10, "alert_type": "threshold", "current_quantity": 9}	f	2025-10-04 00:02:58.941542+02
d2886c40-17b9-486c-bc2d-5cdc0b892d39	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	Stock Alert: Surami	📉 STOCK ALERT - THRESHOLD LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 6\n🎯 Threshold: 10\n📱 Alert Type: THRESHOLD\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:24:31 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "threshold", "current_quantity": 6}	f	2025-10-04 00:24:31.688074+02
957ef040-6ab3-489b-b62f-ac5e1a72e912	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	Stock Alert: Surami	📉 STOCK ALERT - LOW LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 4\n🎯 Threshold: 10\n📱 Alert Type: LOW\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:24:49 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "low", "current_quantity": 4}	f	2025-10-04 00:24:49.101076+02
8bf119c3-6ceb-460e-a20e-a2a5d6aa2d3a	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	Stock Alert: Surami	📉 STOCK ALERT - LOW LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 3\n🎯 Threshold: 10\n📱 Alert Type: LOW\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:24:55 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "low", "current_quantity": 3}	f	2025-10-04 00:24:55.698797+02
0da20431-22f6-41b9-9450-862213796ffc	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	Stock Alert: Surami	📉 STOCK ALERT - CRITICAL LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 1\n🎯 Threshold: 10\n📱 Alert Type: CRITICAL\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:25:01 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "critical", "current_quantity": 1}	f	2025-10-04 00:25:01.250968+02
f0557315-32f3-47d9-8d2f-3634e5d2e968	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	Stock Alert: Surami	📉 STOCK ALERT - CRITICAL LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 0\n🎯 Threshold: 10\n📱 Alert Type: CRITICAL\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:35:57 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "critical", "current_quantity": 0}	f	2025-10-04 00:35:57.265086+02
ae319caf-7670-414e-87e2-a1937a485543	572c001e-2c97-40c1-8276-c73a0bb6572f	Stock Alert: Surami	📉 STOCK ALERT - CRITICAL LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 0\n🎯 Threshold: 10\n📱 Alert Type: CRITICAL\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:36:02 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "critical", "current_quantity": 0}	f	2025-10-04 00:36:02.382458+02
4e788fb4-9116-4479-b55c-1c95a04debc1	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	Stock Alert: Surami	📉 STOCK ALERT - THRESHOLD LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 9\n🎯 Threshold: 10\n📱 Alert Type: THRESHOLD\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:42:42 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "threshold", "current_quantity": 9}	f	2025-10-04 00:42:42.641724+02
e86a2140-0e1d-46d2-9e56-d8504d29ee40	572c001e-2c97-40c1-8276-c73a0bb6572f	Stock Alert: Surami	📉 STOCK ALERT - THRESHOLD LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 9\n🎯 Threshold: 10\n📱 Alert Type: THRESHOLD\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:42:48 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "threshold", "current_quantity": 9}	f	2025-10-04 00:42:48.558361+02
4e53d18c-245a-41fb-b76c-89c805fa07e8	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	Stock Alert: Surami	📉 STOCK ALERT - THRESHOLD LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 6\n🎯 Threshold: 10\n📱 Alert Type: THRESHOLD\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:51:31 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "threshold", "current_quantity": 6}	f	2025-10-04 00:51:31.98803+02
33b7f7c9-8412-4746-bc1e-408251f31e28	572c001e-2c97-40c1-8276-c73a0bb6572f	Stock Alert: Surami	📉 STOCK ALERT - THRESHOLD LEVEL\n\n📦 Item: Surami\n📊 Current Stock: 6\n🎯 Threshold: 10\n📱 Alert Type: THRESHOLD\n\nPlease restock immediately to avoid stockout!\n\nTime: 10/4/2025, 12:51:38 AM	stock_alert	{"source": "moveout_list", "item_name": "Surami", "threshold": 10, "alert_type": "threshold", "current_quantity": 6}	f	2025-10-04 00:51:38.506896+02
\.


--
-- TOC entry 3881 (class 0 OID 16400)
-- Dependencies: 216
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.regions (id, name, description, created_at, updated_at) FROM stdin;
c33dc2c6-297e-482e-8987-de0f188642bd	Main Region	Primary region for operations	2025-10-03 23:55:37.125126+02	2025-10-03 23:55:37.125126+02
\.


--
-- TOC entry 3886 (class 0 OID 16489)
-- Dependencies: 221
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.stock (id, item_id, current_quantity, last_updated, updated_by, created_at, updated_at) FROM stdin;
d715eb43-dd9a-4f15-9119-c1b43f0083fa	9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0	6	2025-10-04 00:42:28.282059+02	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	2025-10-04 00:01:17.942071+02	2025-10-04 00:51:31.940132+02
\.


--
-- TOC entry 3887 (class 0 OID 16509)
-- Dependencies: 222
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.stock_movements (id, item_id, movement_type, quantity, reason, created_by, created_at) FROM stdin;
cba91b67-1f03-4472-a496-f52a27b40b79	9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0	in	10	Quick stock in	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	2025-10-04 00:02:06.476474+02
e76934b3-1228-4069-b28f-ea3d386a6792	9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0	out	1	Quick stock out	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	2025-10-04 00:02:58.896428+02
59f504e6-dfa7-4628-9b5b-1ca7e2725df7	9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0	out	1	Moveout list processing	3edce773-cadd-43f2-ad49-5dc72a2c80a4	2025-10-04 00:35:57.220633+02
eeed7317-0cb9-4e66-b9b2-c4b0f8a07ae0	9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0	in	10	Quick stock in	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	2025-10-04 00:42:28.287731+02
efd1bf4d-fa14-4603-a626-24c9b86ad300	9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0	out	1	Moveout list processing	572c001e-2c97-40c1-8276-c73a0bb6572f	2025-10-04 00:42:42.60139+02
7fc8cea2-508b-4cdd-8ddd-e6a7318f45a6	9915abfa-5327-4d0b-8cfd-2a4eb8d5cdd0	out	3	Moveout list processing	3edce773-cadd-43f2-ad49-5dc72a2c80a4	2025-10-04 00:51:31.944363+02
\.


--
-- TOC entry 3891 (class 0 OID 16608)
-- Dependencies: 226
-- Data for Name: stock_receipts; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.stock_receipts (id, supplier_name, receipt_file_path, receipt_file_name, remarks, status, submitted_by, reviewed_by, branch_id, created_at, updated_at, reviewed_at) FROM stdin;
998e72f3-8498-495d-a63c-c7296fc18f7b	Tingstad	/Users/khalifainternationalaward/Downloads/stock-nexus-84-main 2/backend/uploads/receipts/receipt-1759532044256-601699649.pdf	moveout-list-2025-10-01 (1).pdf	zssss	approved	3edce773-cadd-43f2-ad49-5dc72a2c80a4	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	e3204bd8-ac3d-413f-bd7b-2727e9c7f598	2025-10-04 00:54:04.263588+02	2025-10-04 00:54:24.344769+02	2025-10-04 00:54:24.344769+02
d51304a2-ef61-4772-96e7-6c12d4db03f2	Gronsakshuset	/Users/khalifainternationalaward/Downloads/stock-nexus-84-main 2/backend/uploads/receipts/receipt-1759533187428-279366878.png	Screenshot 2025-09-30 at 03.39.56.png	\N	approved	3edce773-cadd-43f2-ad49-5dc72a2c80a4	ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	e3204bd8-ac3d-413f-bd7b-2727e9c7f598	2025-10-04 01:13:07.433825+02	2025-10-04 01:16:29.530879+02	2025-10-04 01:16:29.530879+02
\.


--
-- TOC entry 3884 (class 0 OID 16442)
-- Dependencies: 219
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: khalifainternationalaward
--

COPY public.users (id, email, password_hash, name, phone, photo_url, "position", role, branch_id, branch_context, last_access, access_count, is_active, created_at, updated_at, region_id, district_id, notification_settings, stock_alert_frequency, stock_alert_schedule_day, stock_alert_schedule_date, stock_alert_schedule_time, stock_alert_frequencies, event_reminder_frequencies, daily_schedule_time, weekly_schedule_day, weekly_schedule_time, monthly_schedule_date, monthly_schedule_time, event_daily_schedule_time, event_weekly_schedule_day, event_weekly_schedule_time, event_monthly_schedule_date, event_monthly_schedule_time) FROM stdin;
572c001e-2c97-40c1-8276-c73a0bb6572f	slaksh7@gmail.com	$2b$10$sCE96Xc2Rdy7wTHEpmntW.oTufIb02ob7U27KjDwCcSqAKpSIa.hm	S Laksh	+1234567891	\N	Manager	staff	bb6313ee-0513-4805-81c2-3072e9618640	\N	2025-10-04 00:50:43.574578+02	10	t	2025-10-03 23:35:01.160034+02	2025-10-04 00:50:43.574578+02	\N	\N	{"sms": false, "email": true, "whatsapp": false, "eventReminders": true, "stockLevelAlerts": true}	\N	\N	\N	\N	[]	[]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
ad23ba39-c4c0-47cd-9f0e-9bf7333cd7f6	aa@aa.com	$2b$10$sCE96Xc2Rdy7wTHEpmntW.oTufIb02ob7U27KjDwCcSqAKpSIa.hm	Jaber Ahmed	+46722204924	\N	Admin	manager	e3204bd8-ac3d-413f-bd7b-2727e9c7f598	\N	2025-10-04 00:54:12.955213+02	6	t	2025-10-03 23:35:01.160034+02	2025-10-04 00:54:12.955213+02	\N	\N	{"sms": false, "email": true, "whatsapp": true, "eventReminders": true, "stockLevelAlerts": true}	immediate	\N	\N	09:00:00	["daily"]	[]	09:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N
3edce773-cadd-43f2-ad49-5dc72a2c80a4	kaumadi19910119@gmail.com	$2b$10$djIULRl/hOiDLObb5j43MeNrZ4XaJaPWUN9UZENzjfq2LcazwITza	Kaumadi Mihirika	\N	\N	\N	staff	e3204bd8-ac3d-413f-bd7b-2727e9c7f598	\N	2025-10-04 00:54:45.711531+02	7	t	2025-10-03 23:35:01.160034+02	2025-10-04 00:54:45.711531+02	\N	\N	{"sms": false, "email": true, "whatsapp": false, "eventReminders": false, "stockLevelAlerts": false}	\N	\N	\N	\N	[]	[]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7c6fc959-5e6e-4b57-ad76-66abb86a16ab	admin@stocknexus.com	$2b$10$sCE96Xc2Rdy7wTHEpmntW.oTufIb02ob7U27KjDwCcSqAKpSIa.hm	System Administrator	+1234567890	\N	System Admin	admin	\N	\N	2025-10-03 23:46:19.491571+02	8	t	2025-10-03 23:30:56.300237+02	2025-10-03 23:48:16.742344+02	\N	\N	{}	\N	\N	\N	\N	[]	[]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 3691 (class 2606 OID 16572)
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3661 (class 2606 OID 16436)
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- TOC entry 3704 (class 2606 OID 16667)
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- TOC entry 3659 (class 2606 OID 16421)
-- Name: districts districts_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_pkey PRIMARY KEY (id);


--
-- TOC entry 3674 (class 2606 OID 16478)
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- TOC entry 3685 (class 2606 OID 16541)
-- Name: moveout_lists moveout_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.moveout_lists
    ADD CONSTRAINT moveout_lists_pkey PRIMARY KEY (id);


--
-- TOC entry 3689 (class 2606 OID 16557)
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- TOC entry 3655 (class 2606 OID 16411)
-- Name: regions regions_name_key; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_name_key UNIQUE (name);


--
-- TOC entry 3657 (class 2606 OID 16409)
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- TOC entry 3681 (class 2606 OID 16518)
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- TOC entry 3677 (class 2606 OID 16498)
-- Name: stock stock_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id);


--
-- TOC entry 3702 (class 2606 OID 16619)
-- Name: stock_receipts stock_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock_receipts
    ADD CONSTRAINT stock_receipts_pkey PRIMARY KEY (id);


--
-- TOC entry 3668 (class 2606 OID 16456)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3670 (class 2606 OID 16454)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3692 (class 1259 OID 16596)
-- Name: idx_activity_logs_branch_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_activity_logs_branch_id ON public.activity_logs USING btree (branch_id);


--
-- TOC entry 3693 (class 1259 OID 16597)
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_activity_logs_created_at ON public.activity_logs USING btree (created_at);


--
-- TOC entry 3694 (class 1259 OID 16652)
-- Name: idx_activity_logs_entity_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_activity_logs_entity_id ON public.activity_logs USING btree (entity_id);


--
-- TOC entry 3695 (class 1259 OID 16651)
-- Name: idx_activity_logs_entity_type; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_activity_logs_entity_type ON public.activity_logs USING btree (entity_type);


--
-- TOC entry 3696 (class 1259 OID 16595)
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_activity_logs_user_id ON public.activity_logs USING btree (user_id);


--
-- TOC entry 3705 (class 1259 OID 16678)
-- Name: idx_calendar_events_branch_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_calendar_events_branch_id ON public.calendar_events USING btree (branch_id);


--
-- TOC entry 3706 (class 1259 OID 16680)
-- Name: idx_calendar_events_created_by; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_calendar_events_created_by ON public.calendar_events USING btree (created_by);


--
-- TOC entry 3707 (class 1259 OID 16679)
-- Name: idx_calendar_events_event_date; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_calendar_events_event_date ON public.calendar_events USING btree (event_date);


--
-- TOC entry 3671 (class 1259 OID 16586)
-- Name: idx_items_branch_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_items_branch_id ON public.items USING btree (branch_id);


--
-- TOC entry 3672 (class 1259 OID 16587)
-- Name: idx_items_category; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_items_category ON public.items USING btree (category);


--
-- TOC entry 3682 (class 1259 OID 16592)
-- Name: idx_moveout_lists_created_at; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_moveout_lists_created_at ON public.moveout_lists USING btree (created_at);


--
-- TOC entry 3683 (class 1259 OID 16591)
-- Name: idx_moveout_lists_created_by; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_moveout_lists_created_by ON public.moveout_lists USING btree (created_by);


--
-- TOC entry 3686 (class 1259 OID 16594)
-- Name: idx_notifications_is_read; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_notifications_is_read ON public.notifications USING btree (is_read);


--
-- TOC entry 3687 (class 1259 OID 16593)
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- TOC entry 3675 (class 1259 OID 16588)
-- Name: idx_stock_item_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_stock_item_id ON public.stock USING btree (item_id);


--
-- TOC entry 3678 (class 1259 OID 16590)
-- Name: idx_stock_movements_created_at; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_stock_movements_created_at ON public.stock_movements USING btree (created_at);


--
-- TOC entry 3679 (class 1259 OID 16589)
-- Name: idx_stock_movements_item_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_stock_movements_item_id ON public.stock_movements USING btree (item_id);


--
-- TOC entry 3697 (class 1259 OID 16637)
-- Name: idx_stock_receipts_branch_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_stock_receipts_branch_id ON public.stock_receipts USING btree (branch_id);


--
-- TOC entry 3698 (class 1259 OID 16638)
-- Name: idx_stock_receipts_created_at; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_stock_receipts_created_at ON public.stock_receipts USING btree (created_at);


--
-- TOC entry 3699 (class 1259 OID 16635)
-- Name: idx_stock_receipts_status; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_stock_receipts_status ON public.stock_receipts USING btree (status);


--
-- TOC entry 3700 (class 1259 OID 16636)
-- Name: idx_stock_receipts_submitted_by; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_stock_receipts_submitted_by ON public.stock_receipts USING btree (submitted_by);


--
-- TOC entry 3662 (class 1259 OID 16585)
-- Name: idx_users_branch_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_users_branch_id ON public.users USING btree (branch_id);


--
-- TOC entry 3663 (class 1259 OID 16650)
-- Name: idx_users_district_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_users_district_id ON public.users USING btree (district_id);


--
-- TOC entry 3664 (class 1259 OID 16583)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3665 (class 1259 OID 16649)
-- Name: idx_users_region_id; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_users_region_id ON public.users USING btree (region_id);


--
-- TOC entry 3666 (class 1259 OID 16584)
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: khalifainternationalaward
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- TOC entry 3733 (class 2620 OID 16601)
-- Name: branches update_branches_updated_at; Type: TRIGGER; Schema: public; Owner: khalifainternationalaward
--

CREATE TRIGGER update_branches_updated_at BEFORE UPDATE ON public.branches FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3732 (class 2620 OID 16600)
-- Name: districts update_districts_updated_at; Type: TRIGGER; Schema: public; Owner: khalifainternationalaward
--

CREATE TRIGGER update_districts_updated_at BEFORE UPDATE ON public.districts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3735 (class 2620 OID 16603)
-- Name: items update_items_updated_at; Type: TRIGGER; Schema: public; Owner: khalifainternationalaward
--

CREATE TRIGGER update_items_updated_at BEFORE UPDATE ON public.items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3737 (class 2620 OID 16605)
-- Name: moveout_lists update_moveout_lists_updated_at; Type: TRIGGER; Schema: public; Owner: khalifainternationalaward
--

CREATE TRIGGER update_moveout_lists_updated_at BEFORE UPDATE ON public.moveout_lists FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3731 (class 2620 OID 16599)
-- Name: regions update_regions_updated_at; Type: TRIGGER; Schema: public; Owner: khalifainternationalaward
--

CREATE TRIGGER update_regions_updated_at BEFORE UPDATE ON public.regions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3736 (class 2620 OID 16604)
-- Name: stock update_stock_updated_at; Type: TRIGGER; Schema: public; Owner: khalifainternationalaward
--

CREATE TRIGGER update_stock_updated_at BEFORE UPDATE ON public.stock FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3734 (class 2620 OID 16602)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: khalifainternationalaward
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3724 (class 2606 OID 16578)
-- Name: activity_logs activity_logs_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- TOC entry 3725 (class 2606 OID 16573)
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3709 (class 2606 OID 16437)
-- Name: branches branches_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON DELETE CASCADE;


--
-- TOC entry 3729 (class 2606 OID 16668)
-- Name: calendar_events calendar_events_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- TOC entry 3730 (class 2606 OID 16673)
-- Name: calendar_events calendar_events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 3708 (class 2606 OID 16422)
-- Name: districts districts_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id) ON DELETE CASCADE;


--
-- TOC entry 3714 (class 2606 OID 16479)
-- Name: items items_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- TOC entry 3715 (class 2606 OID 16484)
-- Name: items items_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 3720 (class 2606 OID 16694)
-- Name: moveout_lists moveout_lists_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.moveout_lists
    ADD CONSTRAINT moveout_lists_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- TOC entry 3721 (class 2606 OID 16542)
-- Name: moveout_lists moveout_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.moveout_lists
    ADD CONSTRAINT moveout_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3722 (class 2606 OID 16689)
-- Name: moveout_lists moveout_lists_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.moveout_lists
    ADD CONSTRAINT moveout_lists_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3723 (class 2606 OID 16558)
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3716 (class 2606 OID 16499)
-- Name: stock stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- TOC entry 3718 (class 2606 OID 16524)
-- Name: stock_movements stock_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 3719 (class 2606 OID 16519)
-- Name: stock_movements stock_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- TOC entry 3726 (class 2606 OID 16630)
-- Name: stock_receipts stock_receipts_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock_receipts
    ADD CONSTRAINT stock_receipts_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- TOC entry 3727 (class 2606 OID 16625)
-- Name: stock_receipts stock_receipts_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock_receipts
    ADD CONSTRAINT stock_receipts_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 3728 (class 2606 OID 16620)
-- Name: stock_receipts stock_receipts_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock_receipts
    ADD CONSTRAINT stock_receipts_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3717 (class 2606 OID 16504)
-- Name: stock stock_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 3710 (class 2606 OID 16462)
-- Name: users users_branch_context_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_branch_context_fkey FOREIGN KEY (branch_context) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- TOC entry 3711 (class 2606 OID 16457)
-- Name: users users_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- TOC entry 3712 (class 2606 OID 16644)
-- Name: users users_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON DELETE SET NULL;


--
-- TOC entry 3713 (class 2606 OID 16639)
-- Name: users users_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khalifainternationalaward
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id) ON DELETE SET NULL;


-- Completed on 2025-10-04 23:12:52 CEST

--
-- PostgreSQL database dump complete
--

\unrestrict jvWi6xLhVJmsh8R116HanHAIemah1K7FLxJbbGCmoZD5L6zT22EUmf3os7mF3xe

